# Product Backlog

Ideas for extending the Password Generation Service. Items describe **what** we want and **why**, not how to build it.

## How to use this backlog

1. Pick an item with status `Open`, preferably the highest priority (P1 first).
2. Set its status to `In progress` and add your name as owner, in both the index and the item.
3. When every acceptance criterion is met, set the status to `Done`.

Principles every item must respect (see [SPEC.md](SPEC.md)): the service stays stateless, and passwords are never stored or logged, except for the documented exceptions (presets, secrets and accounts, see [ADR 0004](docs/decisions/0004-stateless-with-deliberate-exceptions.md)), which are stored on purpose. Passwords and secret values are still never logged.

Priorities: **P1** = next up, **P2** = valuable, **P3** = nice to have.

## Index

| ID      | Title                                    | Area                  | Priority | Status |
| ------- | ---------------------------------------- | --------------------- | -------- | ------ |
| PGS-B01 | Forbidden characters                     | Policy rules          | P1       | Open   |
| PGS-B02 | No consecutive repeating characters      | Policy rules          | P1       | Open   |
| PGS-B03 | Custom special-character set             | Policy rules          | P3       | Open   |
| PGS-B04 | Exclude look-alike characters            | Policy rules          | P2       | Open   |
| PGS-B05 | Detailed validation results              | Validation & feedback | P1       | Open   |
| PGS-B06 | Clear policy-rejection reasons           | Validation & feedback | P1       | Open   |
| PGS-B07 | Password strength estimate               | Validation & feedback | P2       | Open   |
| PGS-B08 | Common password check                    | Validation & feedback | P2       | Open   |
| PGS-B09 | Batch generation                         | Generation            | P2       | Open   |
| PGS-B10 | Passphrase mode                          | Generation            | P2       | Open   |
| PGS-B11 | PIN (numeric-only) mode                  | Generation            | P3       | Open   |
| PGS-B12 | Update the default policy through an API | Policy management     | P2       | Open   |
| PGS-B13 | Named policy presets                     | Policy management     | P3       | Done   |
| PGS-B14 | Rate limiting                            | Operations & security | P2       | Open   |
| PGS-B15 | API access keys                          | Operations & security | P2       | Open   |
| PGS-B16 | Usage metrics                            | Operations & security | P3       | Open   |
| PGS-B17 | Live rule checklist while typing         | Frontend              | P2       | Open   |
| PGS-B18 | Auto-clear copied password               | Frontend              | P2       | Open   |
| PGS-B19 | Accessibility and mobile layout          | Frontend              | P3       | Open   |
| PGS-B21 | Manage custom policy presets             | Policy management     | P3       | Done   |
| PGS-B22 | Polished visual design and dark mode     | Frontend              | P2       | Open   |
| PGS-B23 | Secrets store                            | Secrets & accounts    | P2       | Done   |
| PGS-B24 | Secrets view                             | Secrets & accounts    | P2       | Done   |
| PGS-B25 | Privileged accounts store                | Secrets & accounts    | P2       | Done   |
| PGS-B26 | Privileged accounts view                 | Secrets & accounts    | P2       | Done   |
| PGS-B27 | Generate an account's secret             | Secrets & accounts    | P2       | Open   |
| PGS-B28 | Set an account's secret to a given value | Secrets & accounts    | P2       | Open   |
| PGS-B29 | Account secrets in the Accounts view     | Secrets & accounts    | P2       | Open   |
| PGS-B30 | Compliance interval per account          | Secrets & accounts    | P3       | Open   |
| PGS-B31 | Admin: sample accounts and delete all    | Secrets & accounts    | P3       | Done   |

PGS-B20 (Dark mode) was merged into PGS-B22.

---

## Policy rules

### PGS-B01 — Forbidden characters

**Priority:** P1 · **Status:** Open · **Owner:** —

**Summary:** Let callers exclude specific characters from passwords.

**Description:** Some target systems reject certain symbols or ambiguous characters. Callers should be able to list characters that must never appear. Generated passwords avoid them, and validation rejects passwords that contain them.

**Acceptance criteria:**

- Generated passwords never contain a forbidden character.
- Validation fails for a password that contains one.
- A policy that can no longer be satisfied (e.g. every special character is forbidden but one is required) is rejected with a clear message.
- The frontend policy form lets the user enter forbidden characters.
- The effective alphabet is the base set minus every exclusion (this item, PGS-B03 and PGS-B04). A combination that can no longer be satisfied is rejected with reasons (see PGS-B06).

### PGS-B02 — No consecutive repeating characters

**Priority:** P1 · **Status:** Open · **Owner:** —

**Summary:** Let callers forbid the same character appearing twice in a row.

**Description:** Many corporate policies reject passwords like `aa` or `11`. Repeats that are not adjacent (e.g. `a1a`) stay allowed. The default behavior does not change: `allow_repeats` defaults to true, so repeats are allowed unless the caller says otherwise.

**Acceptance criteria:**

- With `allow_repeats` set to false, generated passwords never contain two identical adjacent characters.
- Validation rejects passwords that do.
- Non-adjacent repeats are still accepted.
- The frontend policy form has a control for it.

### PGS-B03 — Custom special-character set

**Priority:** P3 · **Status:** Open · **Owner:** —

**Summary:** Let callers choose which special characters are allowed.

**Description:** Different systems accept different symbols. Today everyone gets the same fixed set. Callers should be able to narrow it to what their target system accepts.

**Acceptance criteria:**

- Generated passwords only use special characters from the chosen set.
- Validation rejects special characters outside the chosen set.
- Omitting the option keeps today's behavior.
- It combines with PGS-B01 and PGS-B04 into one effective alphabet; an unsatisfiable combination is rejected with reasons.

### PGS-B04 — Exclude look-alike characters

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Offer an option to avoid characters that are easily confused (e.g. `0` and `O`, `1`, `l` and `I`).

**Description:** Passwords that people read aloud or type by hand are easier to get right without look-alike characters. This is a one-switch alternative to listing them by hand with PGS-B01.

**Acceptance criteria:**

- With the option on, generated passwords contain none of the look-alike characters.
- Validation applies the same rule.
- The frontend exposes it as a single checkbox.
- It combines with PGS-B01 and PGS-B03 into one effective alphabet; an unsatisfiable combination is rejected with reasons.

---

## Validation & feedback

### PGS-B05 — Detailed validation results

**Priority:** P1 · **Status:** Open · **Owner:** —

**Summary:** When a password is invalid, tell the user every rule it broke.

**Description:** Today validation only answers yes or no. Users need to know what to fix, and a password can break several rules at once. The answer should list each broken rule with what was expected and what was found.

**Acceptance criteria:**

- An invalid password returns all broken rules, not just the first.
- Each entry says which rule, what was expected, what was found, and a human-readable message.
- A valid password still returns a simple "valid" answer.
- The frontend shows the broken rules as a list.
- Account secret rejections (PGS-B28) use these per-rule results instead of the interim message.

### PGS-B06 — Clear policy-rejection reasons

**Priority:** P1 · **Status:** Open · **Owner:** —

**Summary:** When a requested policy is rejected, explain everything that is wrong with it.

**Description:** A rejected policy should say why, so callers can fix it in one attempt. Today the caller may only learn about one problem at a time. All problems should be reported together (e.g. "minimums add up to more than the minimum length" and "maximum length above the server limit").

**Acceptance criteria:**

- A policy with several problems reports all of them in one response.
- Each problem names the field involved.
- Messages are understandable without reading the specification.
- The frontend shows them next to the policy form.

### PGS-B07 — Password strength estimate

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Show how strong a password is, beyond whether it meets the policy.

**Description:** Meeting a policy does not make a password strong. Users should see a simple rating (e.g. weak / fair / strong) for generated and validated passwords.

**Acceptance criteria:**

- Generate and validate results include a strength rating.
- The rating is explained in plain terms (what it means and how it is calculated).
- The frontend displays it next to the result.

### PGS-B08 — Common password check

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Flag passwords that are known to be commonly used or leaked.

**Description:** A password can satisfy the policy and still be something like `Password1!`. Validation should warn when the password is on a well-known list of weak passwords. The check must not require sending the password to an outside service.

**Acceptance criteria:**

- Validation can report that a password is on the common list.
- The password never leaves the service and is never logged.
- Callers can turn the check on or off.

---

## Generation

### PGS-B09 — Batch generation

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Generate several passwords in a single request.

**Description:** Users who provision many accounts need many passwords at once. They should be able to ask for a number of passwords and get them all back together.

**Acceptance criteria:**

- The caller can request N passwords; all satisfy the policy.
- There is a sensible upper limit on N, with a clear message when exceeded.
- A batch request counts as one request for rate limiting (PGS-B14); the limit on N is what bounds its cost.
- The frontend lets the user choose the count and copy the results.

### PGS-B10 — Passphrase mode

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Generate memorable word-based passphrases as an alternative to random characters.

**Description:** Passphrases such as several random words are easier to remember and type, and can be just as strong when long enough. Callers should be able to choose the number of words and a separator.

**Acceptance criteria:**

- The caller can request a passphrase with a chosen number of words.
- Words are chosen with the same secure randomness as passwords.
- Validation can check passphrases. Only the length rules apply to a passphrase; per-class minimums and the character alphabet do not, and the documentation says so.

### PGS-B11 — PIN (numeric-only) mode

**Priority:** P3 · **Status:** Open · **Owner:** —

**Summary:** Generate numeric-only codes of a chosen length.

**Description:** Some systems only accept digits. A PIN mode avoids having to relax every other rule by hand.

**Acceptance criteria:**

- The caller can request a digits-only code of a given length.
- Validation can check numeric-only codes. Only the length rules apply; per-class minimums for other classes are ignored, and the documentation says so.
- The frontend offers it as a mode.

---

## Policy management

### PGS-B12 — Update the default policy through an API

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Let administrators change the server's default policy without restarting the service.

**Description:** The default policy is currently fixed at startup. Administrators want to adjust it at runtime. This needs an agreement first: the service is stateless today, so we must decide whether changes survive a restart, and only authorized people may make changes, so this needs PGS-B15 (API access keys) first.

**Acceptance criteria:**

- An authorized administrator (PGS-B15) can change the default policy.
- The same consistency rules as at startup apply; invalid changes are rejected with reasons (see PGS-B06).
- Everyone else keeps read-only access to the current default.
- The decision about restart behavior is documented.

### PGS-B13 — Named policy presets

**Priority:** P3 · **Status:** Done · **Owner:** Amir Zahavi

**Summary:** Let callers pick a policy by name (e.g. "Wi-Fi", "Database", "Banking").

**Description:** Teams repeat the same policy settings. Named presets let them say "use the Banking policy" instead of sending every rule.

**Acceptance criteria:**

- The service offers a list of available presets.
- A request can name a preset; explicit overrides still win.
- The frontend lets the user choose a preset to fill the form.

### PGS-B21 — Manage custom policy presets

**Priority:** P3 · **Status:** Done · **Owner:** Amir Zahavi

**Summary:** Let users add their own named presets and remove any preset, including the built-in ones.

**Description:** PGS-B13 offers a fixed set of presets. Teams have their own recurring policies and want to save them under a name, and to remove presets they don't need, built-in ones included. Presets are kept in a local file, so changes survive a restart and are loaded when the server starts. This is a deliberate exception to statelessness: only presets are stored, never passwords. We still need to agree on who may change presets (see PGS-B15). Builds on PGS-B13.

**Acceptance criteria:**

- A user can add a preset under a unique name. It must pass the same consistency rules as any policy, and an invalid preset is rejected with reasons (see PGS-B06).
- Adding a preset with a name that already exists is rejected with a clear message.
- A user can remove any preset, built-in or user-added. Removing an unknown name gives a clear message.
- Changes are saved to a local file and are still there after a restart.
- When no presets file exists yet, the built-in presets are available.
- If the presets file is unreadable or contains an invalid preset, the server refuses to start with a clear message.
- The presets file never contains passwords.
- The frontend lets the user save the current policy form as a preset and remove presets.
- The exception to statelessness is documented.

---

## Secrets & accounts

### PGS-B23 — Secrets store

**Priority:** P2 · **Status:** Done · **Owner:** Amir Zahavi

**Summary:** Keep secrets in a local file so they can be listed, added, changed and removed.

**Description:** First step toward managing secrets and not only generating them. Each secret has a random UUID v4 id, its value, and the times it was created and last updated. Secrets are kept in their own local file, separate from any other stored data, so they survive a restart. For now values are stored unencrypted. This is a deliberate, documented exception to statelessness. Secrets are still never logged or cached. The "last updated" time is what later compliance checks will rely on.

**Acceptance criteria:**

- A secret can be created. The service assigns a UUID v4 id, and sets createdAt and updatedAt (UTC).
- All secrets can be listed, and a single secret can be fetched by id. Both show id, value, createdAt and updatedAt.
- A secret's value can be changed. updatedAt moves forward and createdAt stays the same.
- A secret can be deleted. An unknown id gives a clear "not found" message.
- An empty value is rejected with a clear message.
- Changes are saved to the secrets file and are still there after a restart. If no file exists yet, the store starts empty.
- If the secrets file is unreadable or invalid, the server refuses to start with a clear message.
- Secret values never appear in logs or error messages, and responses are not cacheable.
- The file location is configurable, and the exception to statelessness is documented.

### PGS-B24 — Secrets view

**Priority:** P2 · **Status:** Done · **Owner:** Amir Zahavi

**Summary:** A page in the frontend for seeing and managing all stored secrets.

**Description:** Users need to work with the secrets store (PGS-B23) without calling the API by hand. The app gets navigation between the existing generator/validator page, the Secrets view, and later the Accounts view (PGS-B26). Builds on PGS-B23.

**Acceptance criteria:**

- The user can switch between the generator/validator page and the Secrets view.
- The Secrets view lists every secret with its id, createdAt and updatedAt. Values are masked by default and can be revealed and copied.
- The user can add a secret by typing a value or by generating one with the current policy form.
- The user can change a secret's value and delete a secret, with confirmation before delete.
- Errors from the service are shown using the existing error style.
- Secret values are never stored in browser storage.

### PGS-B25 — Privileged accounts store

**Priority:** P2 · **Status:** Done · **Owner:** Amir Zahavi

**Summary:** Keep privileged accounts, with their policy, in a local file.

**Description:** A privileged account is identified by a unique name and may have a short description. Each account is assigned a password policy by preset name (PGS-B13/B21), which is used to generate and validate its secret. A compliance interval per account is left for PGS-B30. An account may later reference one secret in the secrets store (see PGS-B27). The accounts file never contains secret values. Accounts are kept in their own local file, separate from the secrets file. Builds on PGS-B13. Needs PGS-B23 for the secret reference.

**Acceptance criteria:**

- An account can be created with a name (required, unique), a description (optional, up to 255 characters), and a preset name (required, must exist).
- A duplicate name, a too-long description, or an unknown preset is rejected with a clear message.
- Accounts can be listed, fetched, edited and deleted. An unknown account gives a clear "not found" message.
- An account has an optional secret id and never stores a secret value.
- Removing a preset that an account uses is allowed (the vault owns presets, see ADR 0001). The account keeps the dangling name until it is next saved, and the frontend shows it as "(missing)". Blocking removal would need a new item.
- Changes are saved to the accounts file and are still there after a restart. If no file exists yet, the store starts empty. If the file is unreadable or invalid, the server refuses to start with a clear message.
- The file location is configurable.

### PGS-B26 — Privileged accounts view

**Priority:** P2 · **Status:** Done · **Owner:** Amir Zahavi

**Summary:** A page in the frontend for seeing and managing privileged accounts.

**Description:** Users manage accounts from the UI, next to the Secrets view. Builds on PGS-B24 (navigation) and PGS-B25.

**Acceptance criteria:**

- The Accounts view is reachable from the same navigation as the other pages.
- It lists every account with name, description, preset, and whether a secret is set.
- The user can create, edit and delete accounts. The preset is chosen from the available presets, and the description field enforces the 255-character limit.
- Rejections from the service (duplicate name, unknown preset, etc.) are shown next to the form.

### PGS-B27 — Generate an account's secret

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Give an account a secret generated from its preset policy, and regenerate it later.

**Description:** This item connects the two stores. A user can generate a secret for an account from the account's preset policy. The secret is kept in the secrets store and the account references it by id. Regenerating updates the same stored secret, so its updatedAt shows when the account's secret last changed. A later compliance check (PGS-B30) will compare that time against the account's interval. Builds on PGS-B23 – PGS-B26. Secrets live in the vault service and accounts in the accounts service, so the accounts service calls the vault's secrets and password APIs through its existing `VaultClient`. Deleting a secret from the secrets store does not check whether an account links to it: the account is then left with a missing secret, and the next generate creates a new one and links it. Once linked, a secret can't be unlinked from its account. It is replaced by regenerating, and deleting the account deletes it too.

**Acceptance criteria:**

- The user can generate a secret for an account. It satisfies the account's preset policy, is saved in the secrets store, and is linked to the account.
- Generating again for an account that already has a secret updates the existing stored secret: same id, new value, newer updatedAt, same createdAt.
- If the linked secret no longer exists in the secrets store, generating creates a new secret and links it.
- An account's secret can't be unlinked; the API offers no way to clear the link.
- Deleting an account also deletes its linked secret from the secrets store. If that secret is already gone, the account is still deleted.
- Deleting all accounts (PGS-B31) also deletes the secrets they link to.
- Deleting a secret is never blocked or checked against accounts; an account whose secret was deleted shows it as missing.
- If the vault is down or slow, the user gets a clear "unavailable" message and nothing changes. This covers generate and account delete, so an account is never deleted while its secret stays behind.
- Secret values are never logged and never stored in the accounts file. Responses carrying a value are not cacheable.

### PGS-B28 — Set an account's secret to a given value

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Let a user enter a secret for an account, accepted only if it meets the account's policy.

**Description:** Some secrets are chosen by someone else, e.g. an existing password on a target system. A user can set or replace an account's secret by entering a value, which must pass the account's preset policy. The value is stored and linked the same way as in PGS-B27. Builds on PGS-B27. Detailed per-rule reasons come with PGS-B05; until then the message names the preset and its rules.

**Acceptance criteria:**

- The user can enter a value for an account. It's accepted only if it passes the account's policy.
- A value that fails the policy is rejected with a clear message that names the preset and its rules. The message never contains the value.
- Replacing an account's secret with a new value updates its existing stored secret: same id, new value, newer updatedAt.
- An empty or oversized value is rejected without echoing it.
- If the vault is down or slow, the user gets a clear "unavailable" message and nothing changes.
- Secret values are never logged and never stored in the accounts file.

### PGS-B29 — Account secrets in the Accounts view

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Manage each account's secret from the Accounts view.

**Description:** Users work with account secrets from the UI instead of calling the API by hand. Builds on PGS-B26, PGS-B27 and PGS-B28.

**Acceptance criteria:**

- The Accounts view shows when each account's secret was last changed, or that it is not set or missing.
- It offers Generate, Set and Replace actions. Set and Replace take a typed value, which is masked while typing. There is no Unlink action.
- Rejections from the service (policy not met, vault unavailable) are shown next to the form.
- The delete-account confirmation says that the account's secret is deleted too.
- Secret values are never stored in browser storage.

### PGS-B30 — Compliance interval per account

**Priority:** P3 · **Status:** Open · **Owner:** —

**Summary:** Give each account an interval for how often its secret must change, and flag accounts that are overdue.

**Description:** An account may have a compliance interval: the number of whole days it may keep the same secret before it must change. It was part of the first accounts store and was removed until it is needed. Overdue is judged from the secret's updatedAt, so the check needs PGS-B27. Builds on PGS-B25, PGS-B26 and PGS-B27.

**Acceptance criteria:**

- An account can have an interval in whole days (at least 1), set on create and edit; an invalid value is rejected with a clear message.
- The Accounts view shows the interval and marks accounts whose secret is older than it.

### PGS-B31 — Admin: sample accounts and delete all

**Priority:** P3 · **Status:** Done · **Owner:** Amir Zahavi

**Summary:** An Admin tab that adds sample privileged accounts across several domains and deletes all accounts or all secrets.

**Description:** Demos and manual tests need realistic data without typing it in. Builds on PGS-B25 and PGS-B26.

**Acceptance criteria:**

- The user chooses how many sample accounts to add (1 to 100). They cover bank accounts, Wi-Fi, PCs and laptops, cloud services and databases, each with a fitting preset.
- Sample presets the vault lacks are added first. Existing presets and accounts are never overwritten: a taken name gets the next free one.
- All accounts, or all secrets, can be deleted after a confirmation that shows the count.

---

## Operations & security

### PGS-B14 — Rate limiting

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Protect the service from excessive use.

**Description:** Without limits, one client can overload the service or use validation to guess passwords. Callers who exceed a fair number of requests should be told to slow down.

**Acceptance criteria:**

- Clients that exceed the limit get a clear "too many requests" answer that says when to retry.
- Limits are configurable.
- Normal use is unaffected.

### PGS-B15 — API access keys

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Restrict who can call the service.

**Description:** The service is currently open to anyone who can reach it. Organizations will want to give access only to known applications and revoke it when needed. Today's specification excludes user accounts, so this needs a product decision first. It is a prerequisite of PGS-B12 (and of restricting preset changes from PGS-B21).

**Acceptance criteria:**

- Requests without a valid key are refused with a clear message.
- Keys can be added and revoked by an administrator.
- Keys and passwords are never logged.

### PGS-B16 — Usage metrics

**Priority:** P3 · **Status:** Open · **Owner:** —

**Summary:** Give operators visibility into how the service is used.

**Description:** Operators want to see request volume, error rates, and response times to spot problems early. Only counts and timings are recorded, never passwords or policies tied to a caller.

**Acceptance criteria:**

- Operators can see request counts, error counts, and response times.
- No password or password-derived data appears in any metric.

---

## Frontend

### PGS-B17 — Live rule checklist while typing

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Show which rules a password already meets as the user types.

**Description:** Instead of clicking Validate and getting a yes/no, users see a checklist (length, uppercase, digits, ...) update as they type. The checks run in the browser against the policy from `GET /api/v1/policy`, so no partial password is sent to the service on each keystroke (which would also count against PGS-B14). The rule names and messages match PGS-B05.

**Acceptance criteria:**

- Each rule shows as met or not met while typing.
- No request is made while typing.
- The password is not stored anywhere in the browser.

### PGS-B18 — Auto-clear copied password

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Remove a copied password from the clipboard after a short time.

**Description:** A password left on the clipboard can be pasted into the wrong place or read by other apps. After the user copies a generated password, the clipboard is cleared automatically after a short delay.

**Acceptance criteria:**

- The clipboard is cleared after a set delay (e.g. 30 seconds), only if it still holds that password.
- The user is told that this will happen.

### PGS-B19 — Accessibility and mobile layout

**Priority:** P3 · **Status:** Open · **Owner:** —

**Summary:** Make the page usable with a keyboard, screen reader, and on a phone.

**Description:** The page should work for everyone and on any screen size.

**Acceptance criteria:**

- All actions work with the keyboard alone.
- Results and errors are announced to screen readers.
- The layout is usable on a phone-sized screen.

### PGS-B22 — Polished visual design and dark mode

**Priority:** P2 · **Status:** Open · **Owner:** —

**Summary:** Make the page look modern and feel pleasant to use, not like a bare form, and offer a dark appearance that follows the system setting.

**Description:** Today the page uses unstyled browser controls in plain stacked sections, so it looks unfinished and the important parts don't stand out. A consistent look (spacing, colors, typography, styled buttons and inputs, card-like sections) and clear feedback on actions would make the tool more inviting and easier to scan. The generated password should be the focal point. This item also covers dark mode (the former PGS-B20), since colors are chosen once for both themes. Keyboard, screen-reader and mobile support stay in PGS-B19, and this work must not undo them.

**Acceptance criteria:**

- Sections, inputs and buttons share one consistent visual style (spacing, colors, corner radius, typography).
- The generated password is shown prominently in a large, easy-to-read monospace font.
- Actions give visible feedback: buttons show hover/pressed/disabled states, Copy confirms briefly (e.g. "Copied!"), and Generate/Validate show a loading state while waiting.
- Validation results are clearly distinguished as valid or invalid (color plus icon or text, never color alone).
- Errors appear in a consistent, non-jarring style.
- The page follows the system light/dark preference, and text and results keep readable contrast in both themes.
- No new runtime dependencies are added just for styling, and passwords are still never stored in the browser.

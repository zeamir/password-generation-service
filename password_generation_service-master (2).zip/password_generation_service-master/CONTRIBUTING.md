# Contributing

How to set up, make a change and get it reviewed. To understand how the code fits together first, read [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Set up

Python 3.13 and [Poetry](https://python-poetry.org/) for the two services, Node.js 20+ for the frontend. From the repo root:

```bash
make install
make vault        # terminal 1, port 8000
make accounts     # terminal 2, port 8001
make frontend     # terminal 3, port 5173
```

If a virtualenv is activated in your shell, run `unset VIRTUAL_ENV` first, or Poetry uses the wrong one. Settings come from environment variables; the `.env.example` file in each service lists them, and the [README](README.md#configuration-environment-variables) explains them.

## Pick work

Open items are in [BACKLOG.md](BACKLOG.md). Take one with status `Open` (P1 first), set it to `In progress` with your name in both the index and the item, and set it to `Done` when every acceptance criterion is met. The item's text says *what* and *why*; the *how* is up to you. [SPEC.md](SPEC.md) holds the rules every change must respect, chiefly that generate and validate stay stateless and that passwords and secrets are never logged.

## Make a change

1. Branch from `master`.
2. Write a failing test, then the code ([How tests are written](#how-tests-are-written)).
3. Run `make test` and `make lint` from the repo root. Fix everything they report.
4. Commit with a message that starts with the item id: `PGS-B12: Update the default policy through an API`. Use `PGS-0000:` for work that has no backlog item.
5. Open a pull request. Say what changed and why, and how you tested it.

Update the docs in the same change: the README (endpoints, env vars), SPEC.md (behavior), the item in BACKLOG.md, and [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) if you changed how components fit together. If you make a choice a reader would question, add a record in [docs/decisions/](docs/decisions/).

## Where things go

| You want to... | Do this |
|---|---|
| Add an endpoint to the vault | New router factory in `backend/vault/vault/api/` (or extend one) that takes the logic objects and settings it needs; mount it in `create_app` in `main.py`. Request models go in the router file. The router imports `logic/` only, never `dal/`. |
| Add a policy rule | Add the field to `Policy` and `PolicyOverride` in `logic/policy.py`; extend `Policy.check`; use it in `logic/generator.py` and `logic/validator.py`; add an env var in `config.py` and the README table. |
| Persist new data | A new store in `logic/`, modeled on `PresetStore` or `SecretStore`: lock, save before commit, validate the file at startup. File access goes through `dal.json_file.JsonFileRepository`. Add a `*_file` setting and say it in the README. |
| Add an error case | Define an exception in the `logic/` module that raises it, map it in `api/errors.py` to the `{"error": {"code", "message"}}` shape. Never put request input in the message. |
| Add an account field | `AccountFields` in `accounts.py`, which also validates the stored file; then the Accounts view in `frontend/src/accounts.js`. |
| Change the UI | `frontend/src/`. Calls go through `api.js`. Do not store passwords or secrets in browser storage. |

The vault and accounts packages must not import each other.

## How tests are written

- Build the app with `create_app(Settings(...))` and explicit values, never environment variables. Pass `tmp_path / "..."` for any `*_file`, or leave it unset to keep the data in memory.
- Test through `TestClient` for endpoints, and call `generate_password`, `is_valid_password` and `Policy.check` directly for the pure logic.
- Accounts tests get a fake vault from `tests/conftest.py`; use an `httpx.MockTransport` to simulate a vault that is down or slow.
- Add a test for the failure case too (inconsistent policy, duplicate name, unreadable file).

```bash
make test                                   # both services
cd backend/vault && poetry run pytest tests/test_policy.py::test_name   # one test
```

## Code style

- Python: [Ruff](https://docs.astral.sh/ruff/), line length 100, Google-style docstrings on every module, public class and function (`Args:`, `Returns:`, `Raises:`, `Attributes:` for models). Tests are exempt from missing-docstring checks.
- JavaScript: Prettier, plus JSDoc (`@param`, `@returns`, `@throws`) on exported functions.
- Inline comments only for a non-obvious *why*, not to restate the code.
- `make lint` formats and fixes all of the above.

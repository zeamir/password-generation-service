# Password Generation Service

A demo service that generates passwords from a complexity policy and validates passwords against one. Passwords sent to it are never stored or logged. It is two backend services plus a frontend: the **vault** (generate/validate, policy presets and stored secrets) and **accounts** (privileged accounts). They save to local files: the named policy presets, the secrets you choose to add (stored **unencrypted**, never logged), and privileged accounts (details only, never a secret value). See [SPEC.md](SPEC.md) for the full specification.

**Status:** the vault and accounts services (FastAPI) and the frontend (Vite + vanilla JS) are implemented. Open ideas are in [BACKLOG.md](BACKLOG.md).

## Documentation

| Document | What it covers |
|---|---|
| [SPEC.md](SPEC.md) | What the service does: requirements, API, non-functional rules |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | How it is built: services, modules, request flows, error contract, tests |
| [docs/decisions/](docs/decisions/) | Why: short records of the choices a reader is likely to question |
| [CONTRIBUTING.md](CONTRIBUTING.md) | How to set up, make a change and write tests |
| [BACKLOG.md](BACKLOG.md) | What could come next |

## Quick start

Three apps, each run on its own in its own terminal, from the repo root. Requirements: Python 3.13 and [Poetry](https://python-poetry.org/) for the two services, Node.js 20+ and npm for the frontend.

If a Python virtualenv is activated in your shell, run `unset VIRTUAL_ENV` first, or Poetry will use that one instead of each service's own.

### 1. Vault service (port 8000)

Policy, presets, secrets, and generate/validate. It needs nothing else running.

```bash
cd backend/vault
poetry install
poetry run uvicorn vault.main:app --reload --port 8000
```

Swagger UI: <http://localhost:8000/docs>

### 2. Accounts service (port 8001)

Privileged accounts. It starts on its own, but saving an account checks the preset with the vault, so start the vault first to create or edit accounts (otherwise you get a `503`).

```bash
cd backend/accounts
poetry install
poetry run uvicorn accounts.main:app --reload --port 8001
```

Swagger UI: <http://localhost:8001/docs>

### 3. Frontend (port 5173)

Calls both services directly, so start them first.

```bash
cd frontend
npm install
npm run dev
```

Open <http://localhost:5173>.

Shortcut: after `make install`, run `make vault`, `make accounts` and `make frontend`, one per terminal.

## Backend

Two independent Poetry projects, each with its own virtualenv: `backend/vault` and `backend/accounts`. The accounts service asks the vault whether a preset exists whenever an account is created or edited; nothing else crosses between them.

To run them, see the [Quick start](#quick-start). Interactive API docs (Swagger UI) are at `/docs` on each service, where you can try every endpoint from the browser.

### Try it with curl

```bash
# health
curl localhost:8000/health

# the server's default policy
curl localhost:8000/api/v1/policy

# generate with the default policy
curl -X POST localhost:8000/api/v1/passwords/generate \
  -H 'Content-Type: application/json' -d '{}'

# generate 20 chars, overriding two rules for this request only
curl -X POST localhost:8000/api/v1/passwords/generate \
  -H 'Content-Type: application/json' \
  -d '{"length": 20, "policy": {"min_digits": 4, "min_special": 3}}'

# validate a password against the default policy
curl -X POST localhost:8000/api/v1/passwords/validate \
  -H 'Content-Type: application/json' -d '{"password": "Abcdef1!ghij"}'

# validate against a stricter policy (returns {"valid": false})
curl -X POST localhost:8000/api/v1/passwords/validate \
  -H 'Content-Type: application/json' \
  -d '{"password": "Abcdef1!ghij", "policy": {"min_digits": 3}}'

# an inconsistent policy is rejected with 400 and the reason
curl -i -X POST localhost:8000/api/v1/passwords/generate \
  -H 'Content-Type: application/json' -d '{"policy": {"min_digits": 50}}'

# list the policy presets (built in: Wi-Fi, Database, Banking)
curl localhost:8000/api/v1/presets

# generate from a preset; an explicit policy still wins over it
curl -X POST localhost:8000/api/v1/passwords/generate \
  -H 'Content-Type: application/json' \
  -d '{"preset": "Banking", "policy": {"min_length": 20}}'

# add your own preset (rules you leave out come from the server default)
curl -X POST localhost:8000/api/v1/presets \
  -H 'Content-Type: application/json' \
  -d '{"name": "Team VPN", "policy": {"min_length": 20, "min_special": 2}}'

# remove a preset, built-in or your own
curl -X DELETE 'localhost:8000/api/v1/presets/Team%20VPN'
```

Presets are saved to `local_storage/presets.json` (see `PRESETS_FILE` below) and loaded at startup. There is no authentication yet, so anyone who can reach the service can add and remove presets. To get the built-in presets back, delete the file and restart.

Stored secrets work the same way, in `local_storage/secrets.json` (see `SECRETS_FILE` below). The values are **not encrypted**, and there is no authentication yet, so anyone who can reach the service can read them.

```bash
# store a secret; the response has its id, value, created_at and updated_at
curl -X POST localhost:8000/api/v1/secrets \
  -H 'Content-Type: application/json' -d '{"value": "hunter2"}'

# list, fetch, change and delete (use the id from the create response)
curl localhost:8000/api/v1/secrets
curl localhost:8000/api/v1/secrets/<id>
curl -X PUT localhost:8000/api/v1/secrets/<id> \
  -H 'Content-Type: application/json' -d '{"value": "hunter3"}'
curl -X DELETE localhost:8000/api/v1/secrets/<id>
```

Privileged accounts are saved to `local_storage/accounts.json` (see `ACCOUNTS_FILE` below). Each one names a preset. The accounts service checks the preset with the vault when an account is saved (`400` if the vault has no such preset, `503` if the vault can't be reached). Removing a preset does not touch accounts that use it; they keep the name and show it as missing until edited.

```bash
# create an account (the description is optional, up to 255 characters)
curl -X POST localhost:8001/api/v1/accounts \
  -H 'Content-Type: application/json' \
  -d '{"name": "db-admin", "description": "Production DB", "preset": "Database"}'

# list, fetch, edit (rename too) and delete (use the id from the create response)
curl localhost:8001/api/v1/accounts
curl localhost:8001/api/v1/accounts/<id>
curl -X PUT localhost:8001/api/v1/accounts/<id> \
  -H 'Content-Type: application/json' \
  -d '{"name": "db-root", "preset": "Database"}'
curl -X DELETE localhost:8001/api/v1/accounts/<id>
```

The Admin tab in the frontend fills in sample data and clears it. The same actions are available over the API. There is no authentication yet, so anyone who can reach the services can use them.

```bash
# add the sample presets the vault lacks (Workstation, Cloud and the built-ins); returns the names added
curl -X POST localhost:8000/api/v1/admin/sample-presets

# add 12 sample accounts across banking, Wi-Fi, PCs and laptops, cloud and databases
# (400 if the vault lacks a sample preset, so load the presets first)
curl -X POST localhost:8001/api/v1/admin/sample-accounts \
  -H 'Content-Type: application/json' -d '{"count": 12}'

# delete every account, or every secret; each returns {"deleted": <count>}
curl -X DELETE localhost:8001/api/v1/accounts
curl -X DELETE localhost:8000/api/v1/secrets
```

### Configuration (environment variables)

Vault service:

| Variable | Default | Meaning |
|---|---|---|
| `PASSWORD_POLICY_MIN_LENGTH` | 12 | Default minimum length |
| `PASSWORD_POLICY_MAX_LENGTH` | 64 | Default maximum length |
| `PASSWORD_POLICY_MIN_LOWERCASE` | 1 | Default minimum lowercase chars |
| `PASSWORD_POLICY_MIN_UPPERCASE` | 1 | Default minimum uppercase chars |
| `PASSWORD_POLICY_MIN_DIGITS` | 1 | Default minimum digits |
| `PASSWORD_POLICY_MIN_SPECIAL` | 1 | Default minimum special chars |
| `MAX_LENGTH_CEILING` | 128 | Hard cap on `max_length`, including per-request policies |
| `CORS_ORIGINS` | `http://localhost:5173` | Comma-separated allowed browser origins |
| `PRESETS_FILE` | `local_storage/presets.json` | File the policy presets are saved to (relative to where the server starts) |
| `SECRETS_FILE` | `local_storage/secrets.json` | File the stored secrets are saved to, unencrypted (relative to where the server starts) |

Each service has a `.env.example` listing these with their defaults.

Example: `PASSWORD_POLICY_MIN_LENGTH=16 poetry run uvicorn vault.main:app --reload`

An inconsistent default policy, or an unreadable or invalid presets or secrets file, makes the vault refuse to start.

Accounts service:

| Variable | Default | Meaning |
|---|---|---|
| `ACCOUNTS_FILE` | `local_storage/accounts.json` | File the privileged accounts are saved to (relative to where the server starts) |
| `VAULT_URL` | `http://localhost:8000` | Base URL of the vault service |
| `CORS_ORIGINS` | `http://localhost:5173` | Comma-separated allowed browser origins |

An unreadable or invalid accounts file makes the accounts service refuse to start. It does not need the vault to start.

### Tests

```bash
make test        # both services
# or, per service:
cd backend/vault && poetry run pytest
cd backend/accounts && poetry run pytest
```

### Formatting and linting

Uses [Ruff](https://docs.astral.sh/ruff/) (configured in each service's `pyproject.toml`). `make lint` runs everything, including Prettier. Per service:

```bash
cd backend/vault      # or backend/accounts
poetry run ruff format .          # format
poetry run ruff check --fix .     # lint (and auto-fix)
```

## Frontend

To run the dev server, see the [Quick start](#quick-start). To build static files into `frontend/dist`:

```bash
cd frontend
npm run build
```

The browser calls both services directly: the vault at `http://localhost:8000` and the accounts service at `http://localhost:8001`. Override with `VITE_VAULT_URL` and `VITE_ACCOUNTS_URL` (set at build or dev-server start), and add the page's origin to each service's `CORS_ORIGINS`.

Formatting uses [Prettier](https://prettier.io/) (configured in `frontend/.prettierrc.json`):

```bash
npm run format          # rewrite files
npm run format:check    # check only (for CI)
```

The page has a policy form (pre-filled from `GET /api/v1/policy` and sent with every request) with a preset dropdown and a "Save as preset" button, a Generate panel with a Copy button, and a Validate panel with a show/hide toggle. A Secrets tab lists the stored secrets (masked, with reveal and copy), and lets you add one by typing or generating it, change it, or delete it. An Accounts tab lists the privileged accounts (name, description, preset, and whether a secret is set), and lets you create, edit and delete them; the preset is chosen from the available presets, and service rejections show next to the form. Passwords and secrets are never saved in browser storage.

## License

Proprietary. Copyright (c) 2026 Palo Alto Networks, Inc. All rights reserved. For use in Palo Alto Networks technical interviews only; see [LICENSE](LICENSE).

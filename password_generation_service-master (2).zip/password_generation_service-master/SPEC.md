# Password Generation Service — Specification

## 1. Overview & Goals

A stateless service for managing secrets, with two capabilities:

1. **Generate** a password that satisfies a complexity policy.
2. **Validate** that a given password satisfies a complexity policy.

The policy is supplied by the caller on each request. If the caller omits it (or part of it), the server's default policy applies. A request may also name a **preset** (§2.1) to start from instead of the default.

The service has a Python 3.13 backend exposing a REST API and a JavaScript frontend that uses that API.

### Out of scope

- Storing, logging, or persisting any password. Generated passwords are only returned to the caller.
- User accounts, authentication, or a vault with encryption at rest.

Three things are stored, all deliberate exceptions to statelessness:

- The list of policy presets (§2.1). It holds policies only.
- The stored secrets (§2.2). Passwords passed to `generate` and `validate` are still never stored, but a secret that a user adds on purpose is kept, **unencrypted**, in its own local file.
- The privileged accounts (§2.3). They hold account details only, never a secret value.

### What "validate" means

Because the service keeps no state, it cannot prove that *it* generated a given password. Validation therefore checks that the password **meets the given policy** (i.e. it is a password the generator could have produced under that policy).

## 2. Complexity Policy (MVP)

| Rule            | Meaning                                    | Server default |
|-----------------|--------------------------------------------|----------------|
| `min_length`    | Minimum total length                       | 12             |
| `max_length`    | Maximum total length                       | 64             |
| `min_lowercase` | At least N characters from `a-z`           | 1              |
| `min_uppercase` | At least N characters from `A-Z`           | 1              |
| `min_digits`    | At least N characters from `0-9`           | 1              |
| `min_special`   | At least N characters from the special set | 1              |

- **Allowed alphabet:** lowercase letters, uppercase letters, digits, and the special set
  ``!@#$%^&*()-_=+[]{};:,.<>?/~` ``
- **Per-request policy:** `generate` and `validate` accept an optional `policy` object. Any field omitted falls back to the server default, so a caller can override a single rule.
- **Server default policy:** set via config file or environment variables and loaded at startup; exposed via `GET /api/v1/policy`.
- **Policy consistency** (applies to the server default at startup *and* to every per-request policy):
  every value is an integer ≥ 0, and
  `min_lowercase + min_uppercase + min_digits + min_special ≤ min_length ≤ max_length`.
  - Startup: the service refuses to start if the default policy is inconsistent.
  - Request: an inconsistent policy is rejected with `400`.
- **Server-side hard limits** protect the service from abusive policies: `max_length` may not exceed a configurable ceiling (default 128). A per-request policy beyond the ceiling is rejected with `400`.

### 2.1 Policy presets

A preset is a named, complete policy (e.g. `Wi-Fi`, `Database`, `Banking`).

- **Naming a preset:** `generate` and `validate` accept an optional `preset`. The effective policy is the request `policy` merged over that preset, in place of the server default. An explicit override always wins over the preset. An unknown preset gives `404`.
- **Built-in presets:** `Wi-Fi` (16–63 characters, no special characters required), `Database` (24–64, no special characters required) and `Banking` (12–32, one of each class).
- **Managing presets:** anyone can add a preset under a new name, and remove any preset, built-in or user-added. A new preset is the request `policy` merged over the server default and goes through the same consistency checks as any policy (`400` if inconsistent). An existing name gives `409`, a missing name on removal gives `404`, and a name that is not 1–50 characters of letters, digits, space, `.`, `_` or `-` (starting with a letter or digit) gives `422`.
- **Persistence:** presets are kept in a local JSON file (`PRESETS_FILE`, default `local_storage/presets.json`) that is written after every change and loaded at startup. The file holds names and policies only, never passwords.
  - If the file does not exist, the built-in presets are used. Once it exists it is the complete list, so a removed built-in stays removed. Deleting the file and restarting restores the built-ins.
  - The service refuses to start if the file cannot be read, is malformed, repeats a name, or contains an inconsistent preset.
- **Accounts using a preset:** accounts are a separate service (§2.3) and the vault does not know about them, so removing a preset never fails because of an account. Accounts that still name it keep the name (a dangling reference) until they are edited.
- **Access:** there is no authentication yet, so anyone who can reach the service can change presets. Restrict access before exposing it (see PGS-B15 in the backlog).

### 2.2 Stored secrets

A secret is a value the user chose to keep: `id` (random UUID v4 assigned by the service), `value` (1–1024 characters), `created_at` and `updated_at` (UTC). Changing the value moves `updated_at` forward and leaves `id` and `created_at` alone.

- **Persistence:** secrets are kept in a local JSON file (`SECRETS_FILE`, default `local_storage/secrets.json`), separate from the presets file, written after every change and loaded at startup. Values are **unencrypted**, so restrict access to the file. If it does not exist the store starts empty.
  - The service refuses to start if the file cannot be read, is malformed, or repeats an id. The message never contains secret values.
- **Secrecy:** secret values are never logged and never appear in error messages. Responses from `/api/v1/secrets` carry `Cache-Control: no-store`.
- **Errors:** an unknown id gives `404`, an empty or oversized value, an unknown field or a malformed id gives `422`.
- **Access:** there is no authentication yet, and the list endpoint returns values, so anyone who can reach the service can read every secret. Restrict access before exposing it (see PGS-B15 in the backlog).

### 2.3 Privileged accounts

The accounts live in their own service (default port 8001), separate from the vault that owns presets and secrets. A privileged account describes something whose secret must be changed regularly. It has `id` (random UUID v4 assigned by the service), `name`, `description`, `preset` and `secret_id`.

- **Name:** required, 1–100 characters, unique (compared ignoring case). It can be changed on edit; the `id` is the stable key used in URLs. A name already taken gives `409`.
- **Description:** optional, up to 255 characters.
- **Preset:** required, the name of a preset (§2.1), which sets the policy for the account's secret. The accounts service asks the vault for its presets each time an account is created or edited: an unknown preset gives `400`, and a vault that cannot be reached or answers with an error gives `503` (`unavailable`) and changes nothing. Reading and deleting accounts does not need the vault. A preset removed from the vault later is not detected until the account is next saved.
- **Secret reference:** `secret_id` is null for now. It is reserved for linking an account to a stored secret (§2.2, PGS-B27), is not accepted in requests, and the file never contains a secret value.
- **Persistence:** accounts are kept in their own local JSON file (`ACCOUNTS_FILE`, default `local_storage/accounts.json`), written after every change and loaded at startup. If it does not exist the store starts empty.
  - The service refuses to start if the file cannot be read, is malformed, or repeats an id or a name. It does not need the vault to start.
- **Errors:** an unknown id gives `404`; a wrong type, an over-long field or an unknown field gives `422`.
- **Access:** there is no authentication yet, so anyone who can reach the service can change accounts (see PGS-B15 in the backlog).

## 3. Capability: Generate

- Effective policy = request `policy` merged over the request's `preset` (or the server default if none).
- Output length defaults to the effective `min_length`. The caller may pass an optional `length` within [`min_length`, `max_length`] of the effective policy; otherwise `400`.
- Algorithm: pick the required minimum from each class, fill the remaining length from the full allowed alphabet, then shuffle.
- Randomness **must** come from a cryptographically secure source (Python `secrets` / `secrets.SystemRandom`). The `random` module must not be used.
- The password appears only in the response. It is never stored or logged.

## 4. Capability: Validate

- Effective policy = request `policy` merged over the request's `preset` (or the server default if none).
- Input: a password string. Output: `{ "valid": true | false }`.
- A password is invalid if it breaks any rule of the effective policy, including containing a character outside the allowed alphabet.
- The MVP returns only the yes/no result. Per-rule reasons are in the backlog (§8).

## 5. REST API (v1, JSON)

Two services: the vault (default `http://localhost:8000`) serves everything except `/api/v1/accounts*`, which the accounts service (default `http://localhost:8001`) serves. Both serve `/health` and share the error format.

| Method | Path                         | Request body                                   | Success response                  |
|--------|------------------------------|------------------------------------------------|-----------------------------------|
| GET    | `/api/v1/policy`             | —                                              | `200` default policy + special set |
| GET    | `/api/v1/presets`            | —                                              | `200 { "presets": [{ "name", "policy" }] }` |
| POST   | `/api/v1/presets`            | `{ "name": "...", "policy"?: {...} }`          | `201 { "name", "policy" }`        |
| DELETE | `/api/v1/presets/{name}`     | —                                              | `204`                             |
| GET    | `/api/v1/secrets`            | —                                              | `200 { "secrets": [{ "id", "value", "created_at", "updated_at" }] }` |
| GET    | `/api/v1/secrets/{id}`       | —                                              | `200 { "id", "value", "created_at", "updated_at" }` |
| POST   | `/api/v1/secrets`            | `{ "value": "..." }`                           | `201 { "id", "value", "created_at", "updated_at" }` |
| PUT    | `/api/v1/secrets/{id}`       | `{ "value": "..." }`                           | `200 { "id", "value", "created_at", "updated_at" }` |
| DELETE | `/api/v1/secrets/{id}`       | —                                              | `204`                             |
| DELETE | `/api/v1/secrets`            | —                                              | `200 { "deleted": int }` (all secrets) |
| POST   | `/api/v1/admin/sample-presets` | —                                            | `200 { "added": ["..."] }` (sample presets the vault lacked) |
| GET    | `/api/v1/accounts`           | —                                              | `200 { "accounts": [{ "id", "name", "description", "preset", "secret_id" }] }` |
| GET    | `/api/v1/accounts/{id}`      | —                                              | `200 { "id", "name", ... }`       |
| POST   | `/api/v1/accounts`           | `{ "name", "description"?, "preset" }` | `201 { "id", "name", ... }` |
| PUT    | `/api/v1/accounts/{id}`      | `{ "name", "description"?, "preset" }` | `200 { "id", "name", ... }` |
| DELETE | `/api/v1/accounts/{id}`      | —                                              | `204`                             |
| DELETE | `/api/v1/accounts`           | —                                              | `200 { "deleted": int }` (all accounts) |
| POST   | `/api/v1/admin/sample-accounts` | `{ "count": 1..100 }`                       | `201 { "added": [account] }`      |
| POST   | `/api/v1/passwords/generate` | `{ "length"?: int, "preset"?: "...", "policy"?: {...} }` | `200 { "password": "..." }` |
| POST   | `/api/v1/passwords/validate` | `{ "password": "...", "preset"?: "...", "policy"?: {...} }` | `200 { "valid": bool }` |
| GET    | `/health`                    | —                                              | `200 { "status": "ok" }`          |

Example — generate with a partial policy override:

```json
POST /api/v1/passwords/generate
{ "policy": { "min_length": 20, "min_digits": 4 } }
```

- Passwords always travel in the request/response **body**, never in URLs or query strings, so they stay out of access logs and browser history.
- **Errors:** `{ "error": { "code": "...", "message": "..." } }` with `400` for semantically invalid input (inconsistent policy, length out of range, policy over the hard limits), `404` (`not_found`) for an unknown preset, secret or account, `409` (`conflict`) for a preset or account name that is already taken, `422` for schema errors (wrong types, unknown fields, invalid preset name), and, from the accounts service only, `503` (`unavailable`) when the vault cannot be reached.
- **Headers:** `Cache-Control: no-store` on every password and secret endpoint.

## 6. Frontend (JavaScript)

A single page in vanilla JavaScript, built with Vite, calling the backend REST API. A tab bar switches between the Generator page (policy form, Generate and Validate panels), the Secrets view, the Accounts view and the Admin view.

- **Policy form:** fields for each rule, pre-filled from `GET /api/v1/policy`. The values are sent as the per-request `policy` by both panels.
- **Presets:** a dropdown ("Server default" plus every preset) that fills the policy form, a "Delete preset" button, and a name field with a "Save as preset" button that saves the current form values.
- **Generate panel:** optional length input, "Generate" button, read-only password field, "Copy" button.
- **Validate panel:** masked password input with show/hide toggle, "Validate" button, ✅ / ❌ result.
- **Secrets view:** lists every stored secret with its id, created and updated times. Values are masked and can be revealed and copied. A new secret is added by typing a value or by generating one with the policy form's current values. A secret's value can be changed, and a secret deleted after a confirmation.
- **Accounts view:** lists every account with its name, description, preset and whether a secret is set. A form creates or edits an account: the preset is chosen from the available presets, and the description field stops at 255 characters. Accounts can be deleted after a confirmation. Service rejections (duplicate name, unknown preset, etc.) appear next to the form.
- **Admin view:** a count field (1 to 100) and a "Load sample accounts" button, which first adds any missing sample presets and then that many accounts across banking, Wi-Fi, PCs and laptops, cloud and databases. A taken name is never overwritten; the next free name is used. "Delete all accounts" and "Delete all secrets" buttons ask for a confirmation that shows the count. The current counts are shown.
- Displays server error messages (e.g. inconsistent policy) next to the form.
- Passwords and secrets are never written to `localStorage` or `sessionStorage`.

## 7. Non-Functional Requirements & Tech

- **Backend:** Python 3.13, FastAPI, Pydantic, Uvicorn. Tests with pytest.
- **CORS:** only the configured frontend origin is allowed.
- **Security:** no secrets in logs; HTTPS assumed in deployment; password input capped at 1024 characters; policy hard limits (§2).
- **Testing:**
  - Generator: property-style — for many random policies, every generated password passes the validator under the same policy.
  - Validator: each rule violated in isolation.
  - Policy: merge-with-defaults and consistency/hard-limit rejection.
  - API tests for every endpoint, including error cases.
- **Architecture:** two independent FastAPI services that share no code (the small storage helper and preset-name rule are copied), each with its own Poetry project. The accounts service calls the vault over HTTP (`GET /api/v1/presets`, 2-second timeout) to check presets; account tests use a fake vault.
- **Proposed layout:**
  - `backend/vault/` and `backend/accounts/` — each with a package named after the service (`vault/` or `accounts/`), `tests/` and `pyproject.toml`. In the vault, `api/` has one router per domain and `stores/` the file-backed stores
  - `frontend/` — `index.html`, `src/`, `package.json`

## 8. Backlog (Future Features)

The full, prioritized backlog lives in [BACKLOG.md](BACKLOG.md). The items below are the original detailed notes.

1. **Forbidden characters** — policy option `forbidden_chars`: excluded when generating, rejected when validating.
2. **Allow repeating characters** — policy flag `allow_repeating_chars` (default `true`). "Repeating" means **consecutive** identical characters (e.g. `aa`, `11`). When `false`, the generator never places the same character twice in a row and the validator rejects passwords that do. Non-adjacent repeats (e.g. `a1a`) remain allowed. Note: the generator's final shuffle must respect this constraint.
3. **Detailed validation results** — the validate response lists **every** rule that failed (there can be several), e.g.

   ```json
   {
     "valid": false,
     "violations": [
       { "rule": "min_uppercase", "expected": 2, "actual": 0, "message": "..." },
       { "rule": "min_special",   "expected": 1, "actual": 0, "message": "..." }
     ]
   }
   ```

   The frontend renders these as a list.

Other optional ideas: batch generation, rate limiting, passphrase mode, strength/entropy estimate.

## 9. Open Questions

None. (The default hard ceiling of 128 on `max_length` is confirmed.)

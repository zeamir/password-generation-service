"""Privileged accounts service."""

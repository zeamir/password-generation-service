"""HTTP layer: the account router and the error contract."""

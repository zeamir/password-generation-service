"""Endpoints for privileged accounts."""

import uuid

from fastapi import APIRouter
from fastapi.responses import Response

from accounts.logic.accounts import AccountFields, AccountService


def accounts_router(accounts: AccountService) -> APIRouter:
    """Builds the router for ``/api/v1/accounts``.

    Args:
        accounts: The account service.

    Returns:
        The router.
    """
    router = APIRouter()

    @router.get("/api/v1/accounts")
    def list_accounts():
        """Lists all privileged accounts."""
        return {"accounts": [a.model_dump(mode="json") for a in accounts.list()]}

    @router.get("/api/v1/accounts/{account_id}")
    def get_account(account_id: uuid.UUID):
        """Returns one privileged account."""
        return accounts.get(account_id).model_dump(mode="json")

    @router.post("/api/v1/accounts", status_code=201)
    def create_account(body: AccountFields):
        """Creates an account under a fresh id, if the vault has its preset."""
        return accounts.create(body).model_dump(mode="json")

    @router.put("/api/v1/accounts/{account_id}")
    def update_account(account_id: uuid.UUID, body: AccountFields):
        """Replaces an account's details, keeping its id and secret reference."""
        return accounts.update(account_id, body).model_dump(mode="json")

    @router.delete("/api/v1/accounts")
    def delete_all_accounts():
        """Deletes every account."""
        return {"deleted": accounts.clear()}

    @router.delete("/api/v1/accounts/{account_id}", status_code=204)
    def delete_account(account_id: uuid.UUID):
        """Deletes an account."""
        accounts.delete(account_id)
        return Response(status_code=204)

    return router

"""Admin endpoints: sample data for demos and tests."""

from fastapi import APIRouter
from pydantic import BaseModel, ConfigDict, Field, StrictInt

from accounts.logic.accounts import AccountService

MAX_SAMPLES = 100


class SampleAccountsRequest(BaseModel):
    """Body of ``POST /api/v1/admin/sample-accounts``.

    Attributes:
        count: How many sample accounts to add, 1 to 100.
    """

    model_config = ConfigDict(extra="forbid")

    count: StrictInt = Field(ge=1, le=MAX_SAMPLES)


def admin_router(accounts: AccountService) -> APIRouter:
    """Builds the router for ``/api/v1/admin``.

    Args:
        accounts: The account service.

    Returns:
        The router.
    """
    router = APIRouter()

    @router.post("/api/v1/admin/sample-accounts", status_code=201)
    def add_sample_accounts(body: SampleAccountsRequest):
        """Adds sample accounts across several domains, if the vault has their presets."""
        added = accounts.add_samples(body.count)
        return {"added": [a.model_dump(mode="json") for a in added]}

    return router

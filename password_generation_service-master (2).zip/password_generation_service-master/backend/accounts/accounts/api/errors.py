"""The error contract: every error is ``{"error": {"code", "message"}}``."""

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from accounts.logic.accounts import (
    AccountError,
    AccountExistsError,
    AccountNotFoundError,
    PresetCheckUnavailableError,
)


def error_response(status: int, code: str, message: str) -> JSONResponse:
    """Builds a response in the service's error format.

    Args:
        status: HTTP status code.
        code: Machine-readable error code, e.g. ``invalid_request``.
        message: Human-readable explanation. Must never contain the submitted input.

    Returns:
        A JSON response shaped ``{"error": {"code": ..., "message": ...}}``.
    """
    return JSONResponse(status_code=status, content={"error": {"code": code, "message": message}})


def register_error_handlers(app: FastAPI) -> None:
    """Maps the service's exceptions to error responses.

    Args:
        app: The application to add the handlers to.
    """

    @app.exception_handler(AccountError)
    async def account_error_handler(_: Request, exc: AccountError):
        """Reports an account that names an unknown preset as 400."""
        return error_response(400, "invalid_request", str(exc))

    @app.exception_handler(AccountNotFoundError)
    async def account_not_found_handler(_: Request, exc: AccountNotFoundError):
        """Reports an unknown account id as 404."""
        return error_response(404, "not_found", str(exc))

    @app.exception_handler(AccountExistsError)
    async def account_exists_handler(_: Request, exc: AccountExistsError):
        """Reports a duplicate account name as 409."""
        return error_response(409, "conflict", str(exc))

    @app.exception_handler(PresetCheckUnavailableError)
    async def preset_check_unavailable_handler(_: Request, exc: PresetCheckUnavailableError):
        """Reports that presets could not be checked because the vault is down as 503."""
        return error_response(503, "unavailable", str(exc))

    @app.exception_handler(RequestValidationError)
    async def schema_error_handler(_: Request, exc: RequestValidationError):
        """Reports a malformed request body as 422."""
        # Never echo the submitted input back, to match the vault's handler.
        details = "; ".join(
            f"{'.'.join(str(p) for p in e['loc'] if p != 'body')}: {e['msg']}" for e in exc.errors()
        )
        return error_response(422, "schema_error", details)

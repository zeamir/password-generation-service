"""Server configuration, loaded from environment variables at startup."""

import os
from dataclasses import dataclass
from pathlib import Path

# Default home of the accounts file, relative to where the server starts.
LOCAL_STORAGE_DIR = Path("local_storage")


@dataclass(frozen=True)
class Settings:
    """Immutable server settings.

    Attributes:
        cors_origins: Browser origins allowed to call the API.
        accounts_file: File that privileged accounts are saved to, or None to keep them in memory.
        vault_url: Base URL of the vault service, which owns the policy presets.
    """

    cors_origins: tuple[str, ...] = ("http://localhost:5173",)
    accounts_file: Path | None = None
    vault_url: str = "http://localhost:8000"

    @classmethod
    def from_env(cls) -> "Settings":
        """Builds settings from the environment, falling back to built-in defaults.

        Reads ``CORS_ORIGINS`` (comma-separated), ``ACCOUNTS_FILE`` and ``VAULT_URL``.
        ``ACCOUNTS_FILE`` defaults to ``accounts.json`` inside ``LOCAL_STORAGE_DIR``, which is
        created on the first write.

        Returns:
            The settings.
        """
        origins = os.environ.get("CORS_ORIGINS")
        return cls(
            cors_origins=tuple(o.strip() for o in origins.split(","))
            if origins
            else cls.cors_origins,
            accounts_file=Path(
                os.environ.get("ACCOUNTS_FILE", LOCAL_STORAGE_DIR / "accounts.json")
            ),
            vault_url=os.environ.get("VAULT_URL", cls.vault_url).rstrip("/"),
        )

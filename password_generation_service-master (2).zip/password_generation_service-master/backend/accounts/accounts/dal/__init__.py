"""Data access: the accounts file and the vault service client."""

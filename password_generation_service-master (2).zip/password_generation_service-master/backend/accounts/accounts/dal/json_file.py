"""Reads and writes the small JSON files the stores persist to."""

import json
import os
import tempfile
from pathlib import Path


def write_json_atomic(path: Path, payload: object) -> None:
    """Writes ``payload`` as JSON to ``path`` so a crash cannot leave a half-written file.

    Args:
        path: The file to write. Its directory is created if missing.
        payload: A JSON-serializable value.

    Raises:
        OSError: If the file cannot be written. The previous file is then left untouched.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    # Write to a temp file and rename, so readers only ever see a complete file.
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(payload, file, indent=2)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


class JsonFileRepository:
    """A list of raw records kept in one JSON file shaped ``{collection: [...]}``.

    It knows nothing about what the records mean. With no path it does nothing, so callers
    can keep their data in memory only.

    Attributes:
        path: The file, or None when nothing is persisted.
    """

    def __init__(self, path: Path | None, collection: str):
        """Creates a repository.

        Args:
            path: The file to read and write, or None for no persistence.
            collection: The top-level key that holds the list of records.
        """
        self.path = path
        self._collection = collection

    def load(self) -> list[dict] | None:
        """Reads the records.

        Returns:
            The raw records, or None if there is no path or the file does not exist yet.

        Raises:
            ValueError: If the file cannot be read, is not JSON, or is not shaped
                ``{collection: [objects]}``. The message never includes file content.
        """
        if self.path is None or not self.path.exists():
            return None
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except OSError as exc:
            raise ValueError(f"cannot read {self.path}: {exc.strerror}") from None
        except ValueError:
            # The decoder's message can quote file content, which may be a secret.
            raise ValueError(f"{self.path} is not valid JSON") from None
        records = data.get(self._collection) if isinstance(data, dict) else None
        if (
            not isinstance(data, dict)
            or set(data) != {self._collection}
            or not isinstance(records, list)
            or not all(isinstance(r, dict) for r in records)
        ):
            raise ValueError(f"{self.path} must hold only a {self._collection!r} list of objects")
        return records

    def save(self, records: list[dict]) -> None:
        """Writes the records, replacing the file atomically.

        Args:
            records: JSON-serializable records. Ignored when there is no path.

        Raises:
            OSError: If the file cannot be written. The previous file is then left untouched.
        """
        if self.path is not None:
            write_json_atomic(self.path, {self._collection: records})

"""Client for the vault service, which owns the policy presets."""

import httpx

TIMEOUT_SECONDS = 2.0


class VaultUnavailableError(RuntimeError):
    """The vault service could not be reached or failed to answer."""


class VaultClient:
    """Asks the vault service questions about presets."""

    def __init__(self, client: httpx.Client):
        """Creates a client.

        Args:
            client: HTTP client to use. Its ``base_url`` must be the vault's.
        """
        self._client = client

    @classmethod
    def for_url(cls, vault_url: str) -> "VaultClient":
        """Creates a client that talks to the vault at ``vault_url``.

        Args:
            vault_url: Base URL of the vault service.

        Returns:
            The client, with a short timeout so a slow vault does not hang requests.
        """
        return cls(httpx.Client(base_url=vault_url, timeout=TIMEOUT_SECONDS))

    def preset_names(self) -> set[str]:
        """Fetches the names of the vault's presets.

        Returns:
            The preset names.

        Raises:
            VaultUnavailableError: If the vault cannot be reached or answers with an error.
        """
        try:
            response = self._client.get("/api/v1/presets")
            response.raise_for_status()
            return {preset["name"] for preset in response.json()["presets"]}
        except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
            raise VaultUnavailableError("password vault is unavailable") from exc

    def has_preset(self, name: str) -> bool:
        """Checks whether the vault has a preset with this name.

        Args:
            name: The preset name.

        Returns:
            True if the vault has the preset.

        Raises:
            VaultUnavailableError: If the vault cannot be reached or answers with an error.
        """
        return name in self.preset_names()

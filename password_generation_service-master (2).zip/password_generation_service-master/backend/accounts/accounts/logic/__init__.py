"""Business rules: privileged accounts and their preset check."""

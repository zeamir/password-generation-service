"""Privileged accounts: kept in a local JSON file with their preset.

This is a deliberate exception to statelessness. The file holds account details and an
optional reference to a stored secret (reserved for PGS-B27), never a secret value.
"""

import threading
import uuid
from typing import Annotated

from pydantic import BaseModel, ConfigDict, StringConstraints, ValidationError

from accounts.dal.json_file import JsonFileRepository
from accounts.dal.vault_client import VaultClient, VaultUnavailableError
from accounts.logic.samples import presets_needed, sample_accounts

AccountName = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=100)]
Description = Annotated[str, StringConstraints(max_length=255)]
# Same rules as the vault's preset names, copied because the two services share no code.
PresetName = Annotated[
    str,
    StringConstraints(min_length=1, max_length=50, pattern=r"^[A-Za-z0-9][A-Za-z0-9 ._-]*$"),
]


class AccountError(ValueError):
    """An account refers to something that does not exist, e.g. a preset the vault lacks."""


class AccountNotFoundError(LookupError):
    """No account has the requested id."""


class AccountExistsError(ValueError):
    """An account with that name already exists."""


class PresetCheckUnavailableError(RuntimeError):
    """The vault could not be asked whether a preset exists."""


class AccountFields(BaseModel):
    """The fields a caller chooses when creating or editing an account.

    Attributes:
        name: Unique name, 1 to 100 characters. Compared case-insensitively.
        description: Free text, up to 255 characters.
        preset: Name of the policy preset used to generate and validate the account's secret.
    """

    model_config = ConfigDict(extra="forbid")

    name: AccountName
    description: Description = ""
    preset: PresetName


class Account(AccountFields):
    """One stored account.

    Attributes:
        id: Random UUID v4 assigned by the service.
        secret_id: Id of the account's secret in the secrets store, or None. Never a value.
    """

    id: uuid.UUID
    secret_id: uuid.UUID | None = None


class AccountStore:
    """The set of accounts, saved to the repository after every change."""

    def __init__(self, accounts: dict[uuid.UUID, Account], repo: JsonFileRepository):
        """Creates a store.

        Args:
            accounts: The initial accounts by id.
            repo: Where to save after each change. A repository without a path keeps
                accounts in memory only.
        """
        self._accounts = dict(accounts)
        self._repo = repo
        # Sync endpoints run in a thread pool, so changes must not interleave.
        self._lock = threading.Lock()

    @classmethod
    def load(cls, repo: JsonFileRepository) -> "AccountStore":
        """Loads accounts from ``repo``, or starts empty if there is no file.

        Args:
            repo: The accounts file's repository.

        Returns:
            The loaded store.

        Raises:
            ValueError: If the file cannot be read or parsed, or repeats an id or a name, so the
                server refuses to start.
        """
        path = repo.path
        try:
            records = repo.load()
            if records is None:
                return cls({}, repo)
            # Files written before the compliance interval was removed still carry it.
            loaded = [
                Account.model_validate(
                    {k: v for k, v in record.items() if k != "compliance_interval_days"}
                    if isinstance(record, dict)
                    else record
                )
                for record in records
            ]
        except (ValueError, ValidationError) as exc:
            raise ValueError(f"cannot load accounts file {path}: {exc}") from exc
        accounts = {account.id: account for account in loaded}
        if len(accounts) != len(loaded):
            raise ValueError(f"accounts file {path} repeats an id")
        if len({a.name.casefold() for a in loaded}) != len(loaded):
            raise ValueError(f"accounts file {path} repeats a name")
        return cls(accounts, repo)

    def list(self) -> list[Account]:
        """Returns a snapshot of all accounts, oldest first."""
        with self._lock:
            return list(self._accounts.values())

    def get(self, account_id: uuid.UUID) -> Account:
        """Looks up an account.

        Args:
            account_id: The account's id.

        Returns:
            The account.

        Raises:
            AccountNotFoundError: If there is no account with that id.
        """
        with self._lock:
            return self._find(account_id)

    def create(self, fields: AccountFields) -> Account:
        """Stores a new account and saves the file.

        Args:
            fields: The account's details. The caller checks the preset with the vault.

        Returns:
            The new account, with a fresh id and no secret.

        Raises:
            AccountExistsError: If the name is taken.
            OSError: If the file cannot be written. The account is then not added.
        """
        account = Account(id=uuid.uuid4(), **fields.model_dump())
        with self._lock:
            self._check_name(fields.name, except_id=None)
            self._commit({**self._accounts, account.id: account})
        return account

    def update(self, account_id: uuid.UUID, fields: AccountFields) -> Account:
        """Replaces an account's details and saves the file.

        Args:
            account_id: The account to change.
            fields: The new details. The caller checks the preset with the vault.

        Returns:
            The updated account. Its ``id`` and ``secret_id`` are unchanged.

        Raises:
            AccountNotFoundError: If there is no account with that id.
            AccountExistsError: If the new name belongs to another account.
            OSError: If the file cannot be written. The account is then not changed.
        """
        with self._lock:
            current = self._find(account_id)
            self._check_name(fields.name, except_id=account_id)
            changed = current.model_copy(update=fields.model_dump())
            self._commit({**self._accounts, account_id: changed})
            return changed

    def delete(self, account_id: uuid.UUID) -> None:
        """Removes an account and saves the file.

        Args:
            account_id: The account to remove.

        Raises:
            AccountNotFoundError: If there is no account with that id.
            OSError: If the file cannot be written. The account is then not removed.
        """
        with self._lock:
            self._find(account_id)
            self._commit({k: v for k, v in self._accounts.items() if k != account_id})

    def add_samples(self, count: int) -> tuple[Account, ...]:
        """Stores ``count`` sample accounts and saves the file once.

        Names that are taken are skipped in favor of the next free one, so exactly ``count``
        accounts are added. The caller checks that their presets exist.

        Args:
            count: How many sample accounts to add.

        Returns:
            The new accounts, each with a fresh id and no secret.

        Raises:
            OSError: If the file cannot be written. No account is then added.
        """
        with self._lock:
            taken = {a.name for a in self._accounts.values()}
            added = tuple(
                Account(id=uuid.uuid4(), name=s.name, description=s.description, preset=s.preset)
                for s in sample_accounts(count, taken)
            )
            self._commit({**self._accounts, **{a.id: a for a in added}})
        return added

    def clear(self) -> int:
        """Removes every account and saves the file.

        Returns:
            How many accounts were removed.

        Raises:
            OSError: If the file cannot be written. The accounts are then kept.
        """
        with self._lock:
            count = len(self._accounts)
            self._commit({})
            return count

    def _find(self, account_id: uuid.UUID) -> Account:
        """Returns the account with ``account_id``. The caller must hold the lock."""
        if account_id not in self._accounts:
            raise AccountNotFoundError(f"account {account_id} not found")
        return self._accounts[account_id]

    def _check_name(self, name: str, except_id: uuid.UUID | None) -> None:
        """Rejects a name another account already has. The caller must hold the lock."""
        taken = name.casefold()
        for account in self._accounts.values():
            if account.id != except_id and account.name.casefold() == taken:
                raise AccountExistsError(f"account {name!r} already exists")

    def _commit(self, accounts: dict[uuid.UUID, Account]) -> None:
        """Saves ``accounts`` and only then makes them current, so a failed write changes nothing.

        Args:
            accounts: The full new set. The caller must hold the lock.
        """
        self._repo.save([a.model_dump(mode="json") for a in accounts.values()])
        self._accounts = accounts


class AccountService:
    """Account operations: the store's rules plus the check that a preset exists in the vault."""

    def __init__(self, store: AccountStore, vault: VaultClient):
        """Creates the service.

        Args:
            store: The account store.
            vault: Client used to check that a preset exists.
        """
        self._store = store
        self._vault = vault

    def list(self) -> list[Account]:
        """Returns a snapshot of all accounts, oldest first."""
        return self._store.list()

    def get(self, account_id: uuid.UUID) -> Account:
        """Looks up an account.

        Args:
            account_id: The account's id.

        Returns:
            The account.

        Raises:
            AccountNotFoundError: If there is no account with that id.
        """
        return self._store.get(account_id)

    def create(self, fields: AccountFields) -> Account:
        """Checks the preset with the vault, then stores a new account.

        Args:
            fields: The account's details.

        Returns:
            The new account, with a fresh id and no secret.

        Raises:
            AccountError: If the vault has no such preset.
            PresetCheckUnavailableError: If the vault could not be asked.
            AccountExistsError: If the name is taken.
            OSError: If the file cannot be written. The account is then not added.
        """
        self._require_preset(fields.preset)
        return self._store.create(fields)

    def update(self, account_id: uuid.UUID, fields: AccountFields) -> Account:
        """Checks the preset with the vault, then replaces an account's details.

        Args:
            account_id: The account to change.
            fields: The new details.

        Returns:
            The updated account. Its ``id`` and ``secret_id`` are unchanged.

        Raises:
            AccountError: If the vault has no such preset.
            PresetCheckUnavailableError: If the vault could not be asked.
            AccountNotFoundError: If there is no account with that id.
            AccountExistsError: If the new name belongs to another account.
            OSError: If the file cannot be written. The account is then not changed.
        """
        self._require_preset(fields.preset)
        return self._store.update(account_id, fields)

    def delete(self, account_id: uuid.UUID) -> None:
        """Removes an account.

        Args:
            account_id: The account to remove.

        Raises:
            AccountNotFoundError: If there is no account with that id.
            OSError: If the file cannot be written. The account is then not removed.
        """
        self._store.delete(account_id)

    def add_samples(self, count: int) -> tuple[Account, ...]:
        """Checks that the vault has the sample presets, then adds ``count`` sample accounts.

        Args:
            count: How many sample accounts to add.

        Returns:
            The new accounts.

        Raises:
            AccountError: If the vault lacks a preset the samples use.
            PresetCheckUnavailableError: If the vault could not be asked.
            OSError: If the file cannot be written. No account is then added.
        """
        try:
            existing = self._vault.preset_names()
        except VaultUnavailableError as exc:
            raise PresetCheckUnavailableError(str(exc)) from exc
        missing = sorted(presets_needed(count) - existing)
        if missing:
            raise AccountError(
                f"the vault lacks the presets {', '.join(missing)}; load the sample presets first"
            )
        return self._store.add_samples(count)

    def clear(self) -> int:
        """Removes every account.

        Returns:
            How many accounts were removed.

        Raises:
            OSError: If the file cannot be written. The accounts are then kept.
        """
        return self._store.clear()

    def _require_preset(self, name: str) -> None:
        """Raises unless the vault has the preset.

        Args:
            name: The preset name.

        Raises:
            AccountError: If the vault has no such preset.
            PresetCheckUnavailableError: If the vault could not be asked.
        """
        try:
            exists = self._vault.has_preset(name)
        except VaultUnavailableError as exc:
            raise PresetCheckUnavailableError(str(exc)) from exc
        if not exists:
            raise AccountError(f"preset {name!r} does not exist")

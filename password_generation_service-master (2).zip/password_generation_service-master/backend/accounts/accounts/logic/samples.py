"""Sample privileged accounts across several domains, for demos and tests."""

from collections.abc import Iterator
from itertools import count as counter
from typing import NamedTuple


class Sample(NamedTuple):
    """One sample account's details, before it gets an id.

    Attributes:
        name: The account name.
        description: Free text describing the account.
        preset: Name of the vault preset the account uses.
    """

    name: str
    description: str
    preset: str


# Keyed by preset name. The names are copied from the vault's sample presets on purpose, as the
# two services share no code. Domains are used round-robin, in this order.
SAMPLE_TEMPLATES: dict[str, tuple[tuple[str, str], ...]] = {
    "Banking": (
        ("Corporate treasury portal", "Online banking admin for the company's main bank account"),
        ("Payroll bank account", "Bank login used to run the monthly payroll"),
        ("Corporate card admin", "Admin console for company credit cards"),
    ),
    "Wi-Fi": (
        ("Office Wi-Fi (HQ)", "Pre-shared key for the headquarters staff network"),
        ("Guest Wi-Fi", "Pre-shared key for the visitors' network"),
        ("Warehouse Wi-Fi", "Pre-shared key for the warehouse access points"),
    ),
    "Workstation": (
        ("Finance laptop local admin", "Local administrator on the finance team laptops"),
        ("Reception PC admin", "Local administrator on the front desk PC"),
        ("Design MacBook admin", "Local administrator on the design team MacBooks"),
    ),
    "Cloud": (
        ("AWS root account", "Root user of the main AWS organization"),
        ("Azure global admin", "Global administrator of the Azure tenant"),
        ("Google Workspace super admin", "Super administrator of the company's Google Workspace"),
        ("GitHub org owner", "Owner of the company's GitHub organization"),
    ),
    "Database": (
        ("Production PostgreSQL superuser", "Superuser of the production PostgreSQL cluster"),
        ("Analytics warehouse admin", "Admin of the analytics data warehouse"),
    ),
}


def presets_needed(count: int) -> set[str]:
    """Returns the presets that ``count`` sample accounts use.

    Args:
        count: How many sample accounts are wanted.

    Returns:
        The names of the first ``count`` domains, or of all of them if ``count`` is larger.
    """
    return set(list(SAMPLE_TEMPLATES)[:count])


def _candidates(preset: str) -> Iterator[Sample]:
    """Yields a domain's accounts forever.

    Its templates come first, then again numbered " 2", " 3" and so on.
    """
    templates = SAMPLE_TEMPLATES[preset]
    for round_ in counter():
        suffix = "" if round_ == 0 else f" {round_ + 1}"
        for name, description in templates:
            yield Sample(f"{name}{suffix}", description, preset)


def sample_accounts(count: int, taken: set[str]) -> list[Sample]:
    """Builds ``count`` sample accounts with names that are free.

    Domains are used round-robin, so even a few accounts cover several domains. A name in
    ``taken`` is skipped in favor of the next one in the same domain.

    Args:
        count: How many accounts to build.
        taken: Names that are already used. Compared case-insensitively.

    Returns:
        The accounts, with unique names. The caller checks that their presets exist.
    """
    used = {name.casefold() for name in taken}
    sources = {preset: _candidates(preset) for preset in SAMPLE_TEMPLATES}
    domains = list(SAMPLE_TEMPLATES)
    accounts = []
    for i in range(count):
        source = sources[domains[i % len(domains)]]
        account = next(a for a in source if a.name.casefold() not in used)
        used.add(account.name.casefold())
        accounts.append(account)
    return accounts

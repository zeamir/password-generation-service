"""FastAPI application: wires the repository, vault client, service, router and error contract."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from accounts.api.accounts import accounts_router
from accounts.api.admin import admin_router
from accounts.api.errors import register_error_handlers
from accounts.config import Settings
from accounts.dal.json_file import JsonFileRepository
from accounts.dal.vault_client import VaultClient
from accounts.logic.accounts import AccountService, AccountStore


def create_app(settings: Settings | None = None, vault: VaultClient | None = None) -> FastAPI:
    """Creates the FastAPI application.

    Args:
        settings: Server settings. Read from the environment if omitted.
        vault: Client for the vault service. Built from ``settings.vault_url`` if omitted.

    Returns:
        The configured application.
    """
    settings = settings or Settings.from_env()
    vault = vault or VaultClient.for_url(settings.vault_url)
    # Fails fast at startup when the accounts file is unreadable or invalid.
    store = AccountStore.load(JsonFileRepository(settings.accounts_file, "accounts"))
    app = FastAPI(title="Password Generation Service - Accounts", version="1.0.0")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.cors_origins),
        allow_methods=["GET", "POST", "PUT", "DELETE"],
        allow_headers=["Content-Type"],
    )

    register_error_handlers(app)

    @app.get("/health")
    def health():
        """Reports that the service is up."""
        return {"status": "ok"}

    service = AccountService(store, vault)
    app.include_router(accounts_router(service))
    app.include_router(admin_router(service))
    return app


app = create_app()

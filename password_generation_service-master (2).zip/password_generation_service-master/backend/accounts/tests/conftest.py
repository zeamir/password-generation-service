"""Fixtures: a fake vault service, so account tests need no real vault."""

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from accounts.config import Settings
from accounts.dal.vault_client import VaultClient
from accounts.main import create_app

VAULT_PRESETS = ["Wi-Fi", "Database", "Banking"]


@pytest.fixture
def vault_presets():
    """The preset names the fake vault reports. Tests may change the list."""
    return list(VAULT_PRESETS)


@pytest.fixture
def vault_client(vault_presets):
    """A ``VaultClient`` wired to a fake vault that serves ``vault_presets``."""
    fake = FastAPI()

    @fake.get("/api/v1/presets")
    def list_presets():
        return {"presets": [{"name": name, "policy": {}} for name in vault_presets]}

    return VaultClient(TestClient(fake))


@pytest.fixture
def accounts_file(tmp_path):
    return tmp_path / "accounts.json"


@pytest.fixture
def client(accounts_file, vault_client):
    return TestClient(create_app(Settings(accounts_file=accounts_file), vault_client))

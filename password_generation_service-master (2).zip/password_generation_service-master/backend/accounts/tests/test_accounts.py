"""Tests for the account store (including its file), the endpoints and the vault checks."""

import json
import uuid

import httpx
import pytest
from fastapi.testclient import TestClient

from accounts.config import Settings
from accounts.dal.json_file import JsonFileRepository
from accounts.dal.vault_client import VaultClient
from accounts.logic.accounts import (
    AccountExistsError,
    AccountFields,
    AccountNotFoundError,
    AccountStore,
)
from accounts.main import create_app

ACCOUNTS = "/api/v1/accounts"
BODY = {
    "name": "db-admin",
    "description": "Production database admin",
    "preset": "Database",
}


def fields(**changes):
    return AccountFields(**{**BODY, **changes})


def write_file(path, entries):
    path.write_text(json.dumps({"accounts": entries}))


def entry(**changes):
    return {"id": str(uuid.uuid4()), "secret_id": None, **BODY, **changes}


def test_missing_file_gives_empty_store(accounts_file):
    store = AccountStore.load(JsonFileRepository(accounts_file, "accounts"))
    assert store.list() == []
    assert not accounts_file.exists()


def test_create_assigns_uuid4_and_no_secret():
    account = AccountStore.load(JsonFileRepository(None, "accounts")).create(fields())
    assert account.id.version == 4
    assert account.secret_id is None


def test_update_keeps_id_and_secret_reference():
    store = AccountStore.load(JsonFileRepository(None, "accounts"))
    created = store.create(fields())
    changed = store.update(created.id, fields(name="renamed", description="new"))
    assert (changed.id, changed.secret_id) == (created.id, created.secret_id)
    assert (changed.name, changed.description) == ("renamed", "new")


def test_name_is_unique_ignoring_case():
    store = AccountStore.load(JsonFileRepository(None, "accounts"))
    first = store.create(fields())
    with pytest.raises(AccountExistsError):
        store.create(fields(name="DB-ADMIN"))
    other = store.create(fields(name="other"))
    with pytest.raises(AccountExistsError):
        store.update(other.id, fields(name="Db-Admin"))
    # Keeping its own name on edit is not a clash.
    store.update(first.id, fields(description="changed"))


def test_unknown_id_is_not_found():
    store = AccountStore.load(JsonFileRepository(None, "accounts"))
    for call in (store.get, store.delete, lambda i: store.update(i, fields())):
        with pytest.raises(AccountNotFoundError):
            call(uuid.uuid4())


def test_changes_survive_reload(accounts_file):
    store = AccountStore.load(JsonFileRepository(accounts_file, "accounts"))
    kept = store.create(fields())
    gone = store.create(fields(name="gone"))
    store.update(kept.id, fields(description="kept"))
    store.delete(gone.id)
    reloaded = AccountStore.load(JsonFileRepository(accounts_file, "accounts"))
    assert [(a.id, a.description) for a in reloaded.list()] == [(kept.id, "kept")]


def test_legacy_interval_is_dropped_on_load(accounts_file):
    write_file(accounts_file, [entry(compliance_interval_days=90)])
    store = AccountStore.load(JsonFileRepository(accounts_file, "accounts"))
    [account] = store.list()
    assert not hasattr(account, "compliance_interval_days")
    store.update(account.id, fields(description="changed"))
    assert "compliance_interval_days" not in accounts_file.read_text()


def test_failed_write_changes_nothing(tmp_path):
    blocker = tmp_path / "blocker"
    blocker.write_text("")
    store = AccountStore.load(
        JsonFileRepository(blocker / "accounts.json", "accounts")
    )  # can't create directory
    with pytest.raises(OSError):
        store.create(fields())
    assert store.list() == []


@pytest.mark.parametrize(
    "content",
    [
        "not json",
        json.dumps({"other": []}),
        json.dumps({"accounts": [{"id": "x", "name": "a"}]}),
    ],
)
def test_invalid_file_stops_startup(accounts_file, vault_client, content):
    accounts_file.write_text(content)
    with pytest.raises(ValueError):
        AccountStore.load(JsonFileRepository(accounts_file, "accounts"))
    with pytest.raises(ValueError):
        create_app(Settings(accounts_file=accounts_file), vault_client)


def test_file_with_repeated_id_or_name_stops_startup(accounts_file):
    first = entry()
    write_file(accounts_file, [first, {**entry(name="other"), "id": first["id"]}])
    with pytest.raises(ValueError, match="repeats an id"):
        AccountStore.load(JsonFileRepository(accounts_file, "accounts"))
    write_file(accounts_file, [entry(), entry(name="DB-Admin")])
    with pytest.raises(ValueError, match="repeats a name"):
        AccountStore.load(JsonFileRepository(accounts_file, "accounts"))


def test_api_round_trip(client):
    created = client.post(ACCOUNTS, json=BODY)
    assert created.status_code == 201
    body = created.json()
    assert body == {**BODY, "id": body["id"], "secret_id": None}

    assert client.get(ACCOUNTS).json() == {"accounts": [body]}
    assert client.get(f"{ACCOUNTS}/{body['id']}").json() == body

    renamed = client.put(f"{ACCOUNTS}/{body['id']}", json={**BODY, "name": "renamed"})
    assert renamed.status_code == 200
    assert renamed.json() == {**body, "name": "renamed"}

    assert client.delete(f"{ACCOUNTS}/{body['id']}").status_code == 204
    assert client.get(ACCOUNTS).json() == {"accounts": []}


def test_api_description_is_optional(client):
    body = {k: v for k, v in BODY.items() if k != "description"}
    assert client.post(ACCOUNTS, json=body).json()["description"] == ""


def test_api_duplicate_name_is_409(client):
    client.post(ACCOUNTS, json=BODY)
    response = client.post(ACCOUNTS, json={**BODY, "name": "DB-admin"})
    assert response.status_code == 409
    assert response.json()["error"]["code"] == "conflict"
    other = client.post(ACCOUNTS, json={**BODY, "name": "other"}).json()
    assert client.put(f"{ACCOUNTS}/{other['id']}", json=BODY).status_code == 409


@pytest.mark.parametrize(
    "changes",
    [
        {"description": "x" * 256},
        {"compliance_interval_days": 90},
        {"name": "   "},
        {"name": "x" * 101},
        {"preset": "bad/name"},
        {"secret_id": str(uuid.uuid4())},
    ],
)
def test_api_invalid_fields_are_422(client, changes):
    response = client.post(ACCOUNTS, json={**BODY, **changes})
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "schema_error"


def test_api_description_limit_is_255(client):
    assert client.post(ACCOUNTS, json={**BODY, "description": "x" * 255}).status_code == 201


def test_api_missing_required_fields_are_422(client):
    for field in ("name", "preset"):
        body = {k: v for k, v in BODY.items() if k != field}
        assert client.post(ACCOUNTS, json=body).status_code == 422


def test_api_unknown_preset_is_400(client):
    response = client.post(ACCOUNTS, json={**BODY, "preset": "Nope"})
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "invalid_request"
    created = client.post(ACCOUNTS, json=BODY).json()
    assert (
        client.put(f"{ACCOUNTS}/{created['id']}", json={**BODY, "preset": "Nope"}).status_code
        == 400
    )


def test_api_unknown_id_is_404(client):
    missing = f"{ACCOUNTS}/{uuid.uuid4()}"
    for response in (client.get(missing), client.put(missing, json=BODY), client.delete(missing)):
        assert response.status_code == 404
        assert response.json()["error"]["code"] == "not_found"


def test_api_malformed_id_is_422(client):
    assert client.get(f"{ACCOUNTS}/not-a-uuid").status_code == 422


def test_api_persists_to_file(client, accounts_file, vault_client):
    created = client.post(ACCOUNTS, json=BODY).json()
    restarted = TestClient(create_app(Settings(accounts_file=accounts_file), vault_client))
    assert restarted.get(f"{ACCOUNTS}/{created['id']}").json() == created


def test_account_keeps_a_preset_the_vault_later_removes(client, vault_presets):
    created = client.post(ACCOUNTS, json=BODY).json()
    vault_presets.remove("Database")
    assert client.get(f"{ACCOUNTS}/{created['id']}").json() == created
    # Saving it again is a new write, so the preset is checked again.
    response = client.put(f"{ACCOUNTS}/{created['id']}", json={**BODY, "description": "x"})
    assert response.status_code == 400
    assert client.put(f"{ACCOUNTS}/{created['id']}", json={**BODY, "preset": "Banking"}).is_success


def test_deleting_an_account_does_not_need_the_vault(accounts_file):
    def refuse(request):
        raise httpx.ConnectError("down")

    down = VaultClient(httpx.Client(base_url="http://vault", transport=httpx.MockTransport(refuse)))
    store = AccountStore.load(JsonFileRepository(accounts_file, "accounts"))
    account = store.create(fields())
    app = TestClient(create_app(Settings(accounts_file=accounts_file), down))
    assert app.get(ACCOUNTS).status_code == 200
    assert app.delete(f"{ACCOUNTS}/{account.id}").status_code == 204


@pytest.mark.parametrize(
    "handler",
    [
        lambda request: (_ for _ in ()).throw(httpx.ConnectError("down")),
        lambda request: (_ for _ in ()).throw(httpx.ReadTimeout("slow")),
        lambda request: httpx.Response(500),
        lambda request: httpx.Response(200, json={"unexpected": True}),
    ],
    ids=["unreachable", "timeout", "server-error", "bad-body"],
)
def test_vault_failure_is_503_and_writes_nothing(accounts_file, handler):
    vault = VaultClient(
        httpx.Client(base_url="http://vault", transport=httpx.MockTransport(handler))
    )
    app = TestClient(create_app(Settings(accounts_file=accounts_file), vault))
    response = app.post(ACCOUNTS, json=BODY)
    assert response.status_code == 503
    assert response.json() == {
        "error": {"code": "unavailable", "message": "password vault is unavailable"}
    }
    assert app.get(ACCOUNTS).json() == {"accounts": []}
    assert not accounts_file.exists()

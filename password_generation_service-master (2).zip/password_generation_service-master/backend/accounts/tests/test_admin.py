"""Tests for the sample accounts, delete-all, and the sample generator."""

import json

import httpx
import pytest
from fastapi.testclient import TestClient

from accounts.config import Settings
from accounts.dal.vault_client import VaultClient
from accounts.logic.samples import SAMPLE_TEMPLATES, presets_needed, sample_accounts
from accounts.main import create_app

SAMPLES = "/api/v1/admin/sample-accounts"
ACCOUNTS = "/api/v1/accounts"


@pytest.fixture
def vault_presets():
    return ["Wi-Fi", "Database", "Banking", "Workstation", "Cloud"]


def names(client):
    return [a["name"] for a in client.get(ACCOUNTS).json()["accounts"]]


def saved(accounts_file):
    return json.loads(accounts_file.read_text())["accounts"]


@pytest.mark.parametrize("count", [1, 5, 100])
def test_adds_exactly_count_with_unique_names(client, count):
    response = client.post(SAMPLES, json={"count": count})
    assert response.status_code == 201
    assert len(response.json()["added"]) == count
    stored = names(client)
    assert len(stored) == count
    assert len({n.casefold() for n in stored}) == count


def test_five_accounts_cover_five_domains(client):
    added = client.post(SAMPLES, json={"count": 5}).json()["added"]
    assert {a["preset"] for a in added} == set(SAMPLE_TEMPLATES)
    assert all(a["secret_id"] is None for a in added)


def test_running_twice_adds_numbered_names(client):
    first = client.post(SAMPLES, json={"count": 15}).json()["added"]
    second = client.post(SAMPLES, json={"count": 15}).json()["added"]
    assert len(names(client)) == 30
    assert {a["id"] for a in first}.isdisjoint(a["id"] for a in second)
    assert any(a["name"].endswith(" 2") for a in second)


def test_name_taken_in_another_case_moves_to_the_next_free_name(client):
    client.post(ACCOUNTS, json={"name": "corporate TREASURY portal", "preset": "Banking"})
    client.post(SAMPLES, json={"count": 1})
    assert names(client) == ["corporate TREASURY portal", "Payroll bank account"]


def test_persisted_to_file(client, accounts_file):
    client.post(SAMPLES, json={"count": 3})
    assert len(saved(accounts_file)) == 3


@pytest.mark.parametrize("body", [{"count": 0}, {"count": 101}, {"count": "5"}, {}])
def test_bad_count_is_rejected(client, body):
    response = client.post(SAMPLES, json=body)
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "schema_error"


def test_extra_field_is_rejected(client):
    assert client.post(SAMPLES, json={"count": 1, "preset": "Cloud"}).status_code == 422


def test_missing_preset_is_400_and_nothing_written(client, vault_presets, accounts_file):
    vault_presets.remove("Cloud")
    response = client.post(SAMPLES, json={"count": 5})
    assert response.status_code == 400
    assert "Cloud" in response.json()["error"]["message"]
    assert names(client) == []
    assert not accounts_file.exists()


def test_small_count_only_needs_its_own_presets(client, vault_presets):
    vault_presets.remove("Cloud")
    assert client.post(SAMPLES, json={"count": 3}).status_code == 201


def test_vault_down_is_503_and_nothing_written(accounts_file):
    def refuse(request):
        raise httpx.ConnectError("down")

    vault = VaultClient(
        httpx.Client(base_url="http://vault", transport=httpx.MockTransport(refuse))
    )
    client = TestClient(create_app(Settings(accounts_file=accounts_file), vault))
    response = client.post(SAMPLES, json={"count": 2})
    assert response.status_code == 503
    assert response.json()["error"]["code"] == "unavailable"
    assert not accounts_file.exists()


def test_delete_all_empties_store_and_file(client, accounts_file):
    client.post(SAMPLES, json={"count": 4})
    response = client.delete(ACCOUNTS)
    assert response.status_code == 200
    assert response.json() == {"deleted": 4}
    assert names(client) == []
    assert saved(accounts_file) == []


def test_delete_all_with_no_accounts(client):
    assert client.delete(ACCOUNTS).json() == {"deleted": 0}


def test_sample_accounts_skips_taken_names_within_a_domain():
    got = sample_accounts(5, {"guest wi-fi", "Office Wi-Fi (HQ)"})
    wifi = next(s for s in got if s.preset == "Wi-Fi")
    assert wifi.name == "Warehouse Wi-Fi"


def test_sample_accounts_cycle_through_templates():
    got = sample_accounts(len(SAMPLE_TEMPLATES) * 5, set())
    assert len({s.name for s in got}) == len(got)


def test_presets_needed():
    assert presets_needed(1) == {"Banking"}
    assert presets_needed(50) == set(SAMPLE_TEMPLATES)

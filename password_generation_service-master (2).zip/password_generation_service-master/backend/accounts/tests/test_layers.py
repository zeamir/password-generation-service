"""Checks that the api -> logic -> dal layering is respected."""

import ast
from pathlib import Path

import pytest

PACKAGE = "accounts"
ROOT = Path(__file__).parent.parent / PACKAGE
# Layer -> layers it must not import.
FORBIDDEN = {"api": {"dal"}, "logic": {"api"}, "dal": {"api", "logic"}}


def _imported_layers(path: Path) -> set[str]:
    """Returns the layers of this package that the module at ``path`` imports."""
    layers = set()
    for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
        if isinstance(node, ast.Import):
            names = [alias.name for alias in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module:
            names = [node.module]
        else:
            continue
        for name in names:
            parts = name.split(".")
            if parts[0] == PACKAGE and len(parts) > 1:
                layers.add(parts[1])
    return layers


@pytest.mark.parametrize("layer", FORBIDDEN)
def test_layer_imports_only_allowed_layers(layer):
    modules = sorted((ROOT / layer).glob("*.py"))
    assert modules
    for module in modules:
        bad = _imported_layers(module) & FORBIDDEN[layer]
        assert not bad, f"{module.relative_to(ROOT)} imports {sorted(bad)}"

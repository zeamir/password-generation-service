"""Tests for the admin endpoints and the preset store's ``add_missing``."""

import json

import pytest
from fastapi.testclient import TestClient

from vault.config import Settings
from vault.logic.presets import BUILTIN_PRESETS, SAMPLE_PRESETS
from vault.main import create_app

SAMPLE = "/api/v1/admin/sample-presets"
PRESETS = "/api/v1/presets"


@pytest.fixture
def presets_file(tmp_path):
    return tmp_path / "presets.json"


@pytest.fixture
def client(presets_file):
    return TestClient(create_app(Settings(presets_file=presets_file)))


def names(client):
    return {p["name"] for p in client.get(PRESETS).json()["presets"]}


def test_sample_presets_cover_builtins_and_new_domains():
    assert set(BUILTIN_PRESETS) <= set(SAMPLE_PRESETS)
    assert {"Workstation", "Cloud"} <= set(SAMPLE_PRESETS)


def test_adds_only_the_new_sample_presets(client, presets_file):
    response = client.post(SAMPLE)
    assert response.status_code == 200
    assert sorted(response.json()["added"]) == ["Cloud", "Workstation"]
    assert names(client) == set(SAMPLE_PRESETS)
    saved = json.loads(presets_file.read_text())["presets"]
    assert {e["name"] for e in saved} == set(SAMPLE_PRESETS)


def test_second_call_adds_nothing_and_does_not_write(client, presets_file):
    client.post(SAMPLE)
    before = presets_file.stat().st_mtime_ns
    assert client.post(SAMPLE).json() == {"added": []}
    assert presets_file.stat().st_mtime_ns == before


def test_removed_builtin_comes_back(client):
    client.delete(f"{PRESETS}/Banking")
    assert "Banking" in client.post(SAMPLE).json()["added"]
    assert "Banking" in names(client)


def test_existing_preset_keeps_its_policy(client):
    client.delete(f"{PRESETS}/Cloud")
    client.post(PRESETS, json={"name": "Cloud", "policy": {"min_length": 30, "max_length": 40}})
    client.post(SAMPLE)
    cloud = next(p for p in client.get(PRESETS).json()["presets"] if p["name"] == "Cloud")
    assert cloud["policy"]["min_length"] == 30

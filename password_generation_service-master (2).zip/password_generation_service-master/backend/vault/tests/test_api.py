"""API tests for every endpoint, including error cases."""

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from vault.config import Settings
from vault.logic.policy import Policy, PolicyError
from vault.logic.validator import is_valid_password
from vault.main import create_app

GENERATE = "/api/v1/passwords/generate"
VALIDATE = "/api/v1/passwords/validate"


@pytest.fixture
def client():
    return TestClient(create_app(Settings()))


def test_health(client):
    assert client.get("/health").json() == {"status": "ok"}


def test_get_policy(client):
    body = client.get("/api/v1/policy").json()
    assert body["policy"] == Policy().model_dump()
    assert body["max_length_ceiling"] == 128
    assert "!" in body["special_characters"]


def test_generate_default(client):
    response = client.post(GENERATE, json={})
    assert response.status_code == 200
    assert response.headers["cache-control"] == "no-store"
    assert is_valid_password(response.json()["password"], Policy())


def test_generate_with_policy_and_length(client):
    response = client.post(GENERATE, json={"length": 30, "policy": {"min_digits": 6}})
    password = response.json()["password"]
    assert len(password) == 30
    assert sum(c.isdigit() for c in password) >= 6


def test_generate_rejects_length_out_of_range(client):
    response = client.post(GENERATE, json={"length": 5})
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "invalid_request"


def test_generate_rejects_inconsistent_policy_with_reason(client):
    response = client.post(GENERATE, json={"policy": {"min_digits": 50}})
    assert response.status_code == 400
    assert "exceeds min_length" in response.json()["error"]["message"]


@pytest.mark.parametrize(
    "body",
    [
        {"length": "abc"},
        {"policy": {"min_length": "12"}},
        {"policy": {"unknown_rule": 1}},
        {"unknown": 1},
    ],
)
def test_generate_schema_errors(client, body):
    response = client.post(GENERATE, json=body)
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "schema_error"


def test_validate(client):
    good = client.post(VALIDATE, json={"password": "Abcdef1!ghij"})
    bad = client.post(VALIDATE, json={"password": "abc"})
    assert good.json() == {"valid": True}
    assert bad.json() == {"valid": False}
    assert good.headers["cache-control"] == "no-store"


def test_validate_with_custom_policy(client):
    body = {"password": "Abcdef1!ghij", "policy": {"min_digits": 3}}
    assert client.post(VALIDATE, json=body).json() == {"valid": False}


def test_validate_rejects_inconsistent_policy(client):
    response = client.post(VALIDATE, json={"password": "x", "policy": {"min_length": 2}})
    assert response.status_code == 400


def test_validate_missing_password_is_schema_error(client):
    assert client.post(VALIDATE, json={}).status_code == 422


def test_validate_caps_password_size(client):
    response = client.post(VALIDATE, json={"password": "a" * 1025})
    assert response.status_code == 422


def test_schema_error_does_not_echo_password(client):
    secret = "Sup3r-S3cret!" * 100
    response = client.post(VALIDATE, json={"password": secret})
    assert "Sup3r" not in response.text


def test_cors_allows_only_configured_origin(client):
    ok = client.get("/health", headers={"Origin": "http://localhost:5173"})
    other = client.get("/health", headers={"Origin": "http://evil.example"})
    assert ok.headers["access-control-allow-origin"] == "http://localhost:5173"
    assert "access-control-allow-origin" not in other.headers


def test_inconsistent_default_policy_fails_startup(monkeypatch):
    monkeypatch.setenv("PASSWORD_POLICY_MIN_LENGTH", "2")
    with pytest.raises(PolicyError):
        Settings.from_env()


def test_default_policy_from_env(monkeypatch):
    monkeypatch.setenv("PASSWORD_POLICY_MIN_LENGTH", "16")
    assert Settings.from_env().default_policy.min_length == 16


def test_storage_files_default_to_local_storage(monkeypatch):
    for name in ("PRESETS_FILE", "SECRETS_FILE"):
        monkeypatch.delenv(name, raising=False)
    settings = Settings.from_env()
    assert settings.presets_file == Path("local_storage/presets.json")
    assert settings.secrets_file == Path("local_storage/secrets.json")


def test_storage_files_can_be_overridden_from_env(monkeypatch, tmp_path):
    for name in ("PRESETS_FILE", "SECRETS_FILE"):
        monkeypatch.setenv(name, str(tmp_path / f"{name}.json"))
    settings = Settings.from_env()
    assert settings.presets_file == tmp_path / "PRESETS_FILE.json"
    assert settings.secrets_file == tmp_path / "SECRETS_FILE.json"

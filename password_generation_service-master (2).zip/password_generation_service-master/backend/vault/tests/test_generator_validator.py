"""Generator and validator tests, including a property-style round trip."""

import random

import pytest

from vault.logic.generator import generate_password
from vault.logic.policy import ALPHABET, DIGITS, LOWERCASE, SPECIAL, UPPERCASE, Policy, PolicyError
from vault.logic.validator import is_valid_password


def _random_policy(rng: random.Random) -> Policy:
    mins = [rng.randint(0, 5) for _ in range(4)]
    min_length = sum(mins) + rng.randint(0, 10)
    return Policy(
        min_length=min_length,
        max_length=min_length + rng.randint(0, 20),
        min_lowercase=mins[0],
        min_uppercase=mins[1],
        min_digits=mins[2],
        min_special=mins[3],
    )


def test_generated_passwords_always_pass_validator():
    rng = random.Random(1234)
    for _ in range(300):
        policy = _random_policy(rng)
        length = rng.randint(policy.min_length, policy.max_length)
        password = generate_password(policy, length)
        assert len(password) == length
        assert is_valid_password(password, policy)


def test_default_length_is_min_length():
    assert len(generate_password(Policy(min_length=20))) == 20


@pytest.mark.parametrize("length", [11, 65])
def test_generate_rejects_length_out_of_range(length):
    with pytest.raises(PolicyError):
        generate_password(Policy(), length)


def test_generated_passwords_differ():
    assert len({generate_password(Policy()) for _ in range(50)}) == 50


@pytest.mark.parametrize(
    "password",
    [
        "Abcdef1!ghij",  # control: valid
    ],
)
def test_validator_accepts_valid(password):
    assert is_valid_password(password, Policy())


@pytest.mark.parametrize(
    "password, reason",
    [
        ("Ab1!", "too short"),
        ("Abcdefg1!" + "x" * 60, "too long"),
        ("ABCDEF1!GHIJ", "no lowercase"),
        ("abcdef1!ghij", "no uppercase"),
        ("Abcdefg!ghij", "no digit"),
        ("Abcdefg1ghij", "no special"),
        ("Abcdef1!ghi é", "char outside the alphabet"),
        ("Abcdef1! hij", "space is not allowed"),
    ],
)
def test_validator_rejects_each_violation(password, reason):
    assert not is_valid_password(password, Policy()), reason


def test_validator_respects_stricter_policy():
    policy = Policy(min_length=12, min_digits=3)
    assert not is_valid_password("Abcdef1!ghij", policy)
    assert is_valid_password("Abcde123!ghi", policy)


def test_alphabet_classes_do_not_overlap():
    classes = [LOWERCASE, UPPERCASE, DIGITS, SPECIAL]
    assert sum(len(c) for c in classes) == len(set(ALPHABET))

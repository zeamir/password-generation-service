"""Policy tests: merging with defaults, consistency, and hard-limit rejection."""

import pytest

from vault.logic.policy import Policy, PolicyError, PolicyOverride, resolve_policy

CEILING = 128


def test_override_merges_over_default():
    policy = resolve_policy(Policy(), PolicyOverride(min_length=20, min_digits=4), CEILING)
    assert policy.min_length == 20
    assert policy.min_digits == 4
    assert policy.min_lowercase == 1


def test_no_override_returns_default():
    assert resolve_policy(Policy(), None, CEILING) == Policy()


@pytest.mark.parametrize(
    "override, expected_text",
    [
        (PolicyOverride(min_length=-1), "must be >= 0"),
        (PolicyOverride(min_digits=20), "exceeds min_length"),
        (PolicyOverride(min_length=70), "must not exceed max_length"),
        (PolicyOverride(max_length=129), "server limit"),
    ],
)
def test_inconsistent_policy_is_rejected_with_reason(override, expected_text):
    with pytest.raises(PolicyError, match=expected_text):
        resolve_policy(Policy(), override, CEILING)

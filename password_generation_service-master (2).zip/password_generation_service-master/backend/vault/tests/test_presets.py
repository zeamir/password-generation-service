"""Tests for the preset store (including its file) and the preset endpoints."""

import json
import re

import pytest
from fastapi.testclient import TestClient

from vault.config import Settings
from vault.dal.json_file import JsonFileRepository
from vault.logic.policy import Policy, PolicyError, PolicyOverride
from vault.logic.presets import (
    BUILTIN_PRESETS,
    PresetExistsError,
    PresetNotFoundError,
    PresetStore,
)
from vault.logic.validator import is_valid_password
from vault.main import create_app

PRESETS = "/api/v1/presets"
GENERATE = "/api/v1/passwords/generate"
VALIDATE = "/api/v1/passwords/validate"


@pytest.fixture
def presets_file(tmp_path):
    return tmp_path / "presets.json"


@pytest.fixture
def client(presets_file):
    return TestClient(create_app(Settings(presets_file=presets_file)))


def write_file(path, entries):
    path.write_text(json.dumps({"presets": entries}))


def test_builtin_presets_are_consistent():
    for policy in BUILTIN_PRESETS.values():
        policy.check(128)


def test_missing_file_gives_builtin_presets(presets_file):
    store = PresetStore.load(JsonFileRepository(presets_file, "presets"), 128)
    assert store.list() == BUILTIN_PRESETS
    assert not presets_file.exists()


def test_in_memory_store_has_no_file():
    store = PresetStore.load(JsonFileRepository(None, "presets"), 128)
    store.add("Mine", None, Policy(), 128)
    assert "Mine" in store.list()


def test_changes_survive_reload_including_removed_builtin(presets_file):
    store = PresetStore.load(JsonFileRepository(presets_file, "presets"), 128)
    store.add("Mine", PolicyOverride(min_length=20), Policy(), 128)
    store.remove("Wi-Fi")

    reloaded = PresetStore.load(JsonFileRepository(presets_file, "presets"), 128).list()
    assert reloaded["Mine"] == Policy(min_length=20)
    assert "Wi-Fi" not in reloaded
    assert reloaded["Banking"] == BUILTIN_PRESETS["Banking"]


def test_add_duplicate_and_remove_unknown_are_rejected(presets_file):
    store = PresetStore.load(JsonFileRepository(presets_file, "presets"), 128)
    with pytest.raises(PresetExistsError):
        store.add("Banking", None, Policy(), 128)
    with pytest.raises(PresetNotFoundError):
        store.remove("Nope")
    with pytest.raises(PresetNotFoundError):
        store.get("Nope")


def test_failed_write_changes_nothing(tmp_path):
    blocker = tmp_path / "blocker"
    blocker.write_text("")
    store = PresetStore.load(JsonFileRepository(blocker / "presets.json", "presets"), 128)
    with pytest.raises(OSError):
        store.add("Mine", None, Policy(), 128)
    assert store.list() == BUILTIN_PRESETS


def test_file_holds_only_policies(presets_file):
    PresetStore.load(JsonFileRepository(presets_file, "presets"), 128).add(
        "Mine", None, Policy(), 128
    )
    data = json.loads(presets_file.read_text())
    assert set(data) == {"presets"}
    assert set(data["presets"][0]) == {"name", "policy"}


@pytest.mark.parametrize(
    ("content", "error"),
    [
        ("not json", ValueError),
        ('{"presets": [{"name": "A", "policy": {"min_length": 1}}], "extra": 1}', ValueError),
        ('{"presets": [{"name": "bad/name", "policy": {}}]}', ValueError),
        (
            '{"presets": [{"name": "A", "policy": {}}, {"name": "A", "policy": {}}]}',
            ValueError,
        ),
        ('{"presets": [{"name": "A", "policy": {"min_digits": 50}}]}', PolicyError),
        ('{"presets": [{"name": "A", "policy": {"max_length": 500}}]}', PolicyError),
    ],
)
def test_bad_file_refuses_to_load(presets_file, content, error):
    presets_file.write_text(content)
    with pytest.raises(error, match=re.escape(str(presets_file))):
        PresetStore.load(JsonFileRepository(presets_file, "presets"), 128)


def test_bad_file_stops_the_app_from_starting(presets_file):
    presets_file.write_text("not json")
    with pytest.raises(ValueError, match="cannot load presets file"):
        create_app(Settings(presets_file=presets_file))


def test_list_presets(client):
    body = client.get(PRESETS).json()
    assert [p["name"] for p in body["presets"]] == list(BUILTIN_PRESETS)
    assert body["presets"][0]["policy"] == BUILTIN_PRESETS["Wi-Fi"].model_dump()


def test_generate_and_validate_with_preset(client):
    banking = BUILTIN_PRESETS["Banking"]
    password = client.post(GENERATE, json={"preset": "Banking", "length": 32}).json()["password"]
    assert is_valid_password(password, banking)
    assert len(client.post(GENERATE, json={"preset": "Wi-Fi"}).json()["password"]) == 16
    # Valid for the default policy but shorter than the Wi-Fi minimum.
    short = client.post(GENERATE, json={}).json()["password"]
    assert client.post(VALIDATE, json={"password": short}).json() == {"valid": True}
    assert client.post(VALIDATE, json={"password": short, "preset": "Wi-Fi"}).json() == {
        "valid": False
    }


def test_explicit_override_wins_over_preset(client):
    response = client.post(GENERATE, json={"preset": "Wi-Fi", "policy": {"min_length": 20}})
    assert len(response.json()["password"]) == 20


def test_override_on_preset_is_still_checked(client):
    response = client.post(GENERATE, json={"preset": "Banking", "policy": {"max_length": 5}})
    assert response.status_code == 400


def test_unknown_preset_is_404(client):
    for path, body in [(GENERATE, {}), (VALIDATE, {"password": "x"})]:
        response = client.post(path, json={**body, "preset": "Nope"})
        assert response.status_code == 404
        assert response.json()["error"]["code"] == "not_found"


def test_add_preset(client, presets_file):
    response = client.post(PRESETS, json={"name": "Mine", "policy": {"min_length": 20}})
    assert response.status_code == 201
    assert response.json() == {"name": "Mine", "policy": Policy(min_length=20).model_dump()}
    assert "Mine" in [p["name"] for p in client.get(PRESETS).json()["presets"]]
    assert presets_file.exists()
    assert len(client.post(GENERATE, json={"preset": "Mine"}).json()["password"]) == 20


def test_add_duplicate_preset_is_409(client):
    response = client.post(PRESETS, json={"name": "Banking"})
    assert response.status_code == 409
    assert response.json()["error"]["code"] == "conflict"


def test_add_inconsistent_preset_is_400(client):
    response = client.post(PRESETS, json={"name": "Bad", "policy": {"min_digits": 50}})
    assert response.status_code == 400
    assert "exceeds min_length" in response.json()["error"]["message"]
    assert "Bad" not in [p["name"] for p in client.get(PRESETS).json()["presets"]]


@pytest.mark.parametrize("name", ["", " lead", "a/b", "x" * 51, 5])
def test_add_preset_with_bad_name_is_422(client, name):
    response = client.post(PRESETS, json={"name": name})
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "schema_error"


def test_delete_preset(client):
    assert client.delete(f"{PRESETS}/Wi-Fi").status_code == 204
    assert "Wi-Fi" not in [p["name"] for p in client.get(PRESETS).json()["presets"]]
    assert client.post(GENERATE, json={"preset": "Wi-Fi"}).status_code == 404


def test_delete_unknown_preset_is_404(client):
    response = client.delete(f"{PRESETS}/Nope")
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "not_found"


def test_presets_persist_across_restart(presets_file):
    first = TestClient(create_app(Settings(presets_file=presets_file)))
    first.post(PRESETS, json={"name": "Mine", "policy": {"min_length": 20}})
    first.delete(f"{PRESETS}/Database")

    second = TestClient(create_app(Settings(presets_file=presets_file)))
    names = [p["name"] for p in second.get(PRESETS).json()["presets"]]
    assert names == ["Wi-Fi", "Banking", "Mine"]


def test_preset_responses_for_passwords_stay_no_store(client):
    response = client.post(GENERATE, json={"preset": "Banking"})
    assert response.headers["cache-control"] == "no-store"


def test_file_is_loaded_when_the_server_starts(presets_file):
    write_file(presets_file, [{"name": "Only", "policy": {"min_length": 14}}])
    client = TestClient(create_app(Settings(presets_file=presets_file)))
    assert client.get(PRESETS).json()["presets"] == [
        {"name": "Only", "policy": Policy(min_length=14).model_dump()}
    ]

"""Tests for the secret store (including its file) and the secret endpoints."""

import json
import uuid

import pytest
from fastapi.testclient import TestClient

from vault.config import Settings
from vault.dal.json_file import JsonFileRepository
from vault.logic.secrets import SecretNotFoundError, SecretStore
from vault.main import create_app

SECRETS = "/api/v1/secrets"
VALUE = "s3cr3t-Value!"


@pytest.fixture
def secrets_file(tmp_path):
    return tmp_path / "secrets.json"


@pytest.fixture
def client(secrets_file):
    return TestClient(create_app(Settings(secrets_file=secrets_file)))


def test_missing_file_gives_empty_store(secrets_file):
    store = SecretStore.load(JsonFileRepository(secrets_file, "secrets"))
    assert store.list() == []
    assert not secrets_file.exists()


def test_in_memory_store_has_no_file():
    store = SecretStore.load(JsonFileRepository(None, "secrets"))
    created = store.create(VALUE)
    assert store.get(created.id) == created


def test_create_assigns_uuid4_and_times():
    secret = SecretStore.load(JsonFileRepository(None, "secrets")).create(VALUE)
    assert secret.id.version == 4
    assert secret.created_at == secret.updated_at
    assert secret.created_at.utcoffset().total_seconds() == 0


def test_update_moves_updated_at_only():
    store = SecretStore.load(JsonFileRepository(None, "secrets"))
    created = store.create(VALUE)
    changed = store.update(created.id, "other")
    assert changed.id == created.id
    assert changed.value == "other"
    assert changed.created_at == created.created_at
    assert changed.updated_at > created.updated_at


def test_unknown_id_is_not_found():
    store = SecretStore.load(JsonFileRepository(None, "secrets"))
    for call in (store.get, store.delete, lambda i: store.update(i, VALUE)):
        with pytest.raises(SecretNotFoundError):
            call(uuid.uuid4())


def test_changes_survive_reload(secrets_file):
    store = SecretStore.load(JsonFileRepository(secrets_file, "secrets"))
    kept = store.create("keep")
    gone = store.create("drop")
    store.update(kept.id, "kept-new")
    store.delete(gone.id)
    reloaded = SecretStore.load(JsonFileRepository(secrets_file, "secrets"))
    assert [(s.id, s.value) for s in reloaded.list()] == [(kept.id, "kept-new")]


def test_failed_write_changes_nothing(tmp_path):
    blocker = tmp_path / "blocker"
    blocker.write_text("")
    store = SecretStore.load(
        JsonFileRepository(blocker / "secrets.json", "secrets")
    )  # directory can't be created
    with pytest.raises(OSError):
        store.create(VALUE)
    assert store.list() == []


@pytest.mark.parametrize(
    "content",
    [
        "not json",
        json.dumps({"secrets": [{"id": "x", "value": VALUE}]}),
        json.dumps({"other": []}),
    ],
)
def test_invalid_file_stops_startup_without_leaking_values(secrets_file, content):
    secrets_file.write_text(content)
    with pytest.raises(ValueError) as error:
        SecretStore.load(JsonFileRepository(secrets_file, "secrets"))
    assert VALUE not in str(error.value)
    with pytest.raises(ValueError):
        create_app(Settings(secrets_file=secrets_file))


def test_duplicate_id_in_file_stops_startup(secrets_file):
    entry = {
        "id": str(uuid.uuid4()),
        "value": VALUE,
        "created_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-01-01T00:00:00Z",
    }
    secrets_file.write_text(json.dumps({"secrets": [entry, entry]}))
    with pytest.raises(ValueError, match="repeats an id"):
        SecretStore.load(JsonFileRepository(secrets_file, "secrets"))


def test_api_round_trip(client):
    created = client.post(SECRETS, json={"value": VALUE})
    assert created.status_code == 201
    body = created.json()
    assert set(body) == {"id", "value", "created_at", "updated_at"}
    assert body["value"] == VALUE

    assert client.get(SECRETS).json() == {"secrets": [body]}
    assert client.get(f"{SECRETS}/{body['id']}").json() == body

    updated = client.put(f"{SECRETS}/{body['id']}", json={"value": "new"})
    assert updated.status_code == 200
    assert updated.json()["value"] == "new"
    assert updated.json()["created_at"] == body["created_at"]

    assert client.delete(f"{SECRETS}/{body['id']}").status_code == 204
    assert client.get(SECRETS).json() == {"secrets": []}


def test_api_unknown_id_is_404(client):
    missing = f"{SECRETS}/{uuid.uuid4()}"
    for response in (
        client.get(missing),
        client.put(missing, json={"value": VALUE}),
        client.delete(missing),
    ):
        assert response.status_code == 404
        assert response.json()["error"]["code"] == "not_found"


def test_api_rejects_empty_and_extra_fields_without_echoing(client):
    for body in ({"value": ""}, {"value": VALUE, "extra": 1}, {}):
        response = client.post(SECRETS, json=body)
        assert response.status_code == 422
        assert response.json()["error"]["code"] == "schema_error"
        assert VALUE not in response.text


def test_api_malformed_id_is_422(client):
    response = client.get(f"{SECRETS}/not-a-uuid")
    assert response.status_code == 422
    assert "not-a-uuid" not in response.text


def test_api_responses_are_not_cacheable(client):
    created = client.post(SECRETS, json={"value": VALUE}).json()
    for response in (
        client.get(SECRETS),
        client.get(f"{SECRETS}/{created['id']}"),
        client.get(f"{SECRETS}/{uuid.uuid4()}"),
    ):
        assert response.headers["Cache-Control"] == "no-store"


def test_api_persists_to_file(client, secrets_file):
    created = client.post(SECRETS, json={"value": VALUE}).json()
    restarted = TestClient(create_app(Settings(secrets_file=secrets_file)))
    assert restarted.get(f"{SECRETS}/{created['id']}").json() == created


def test_delete_all_empties_store_and_file(client, secrets_file):
    client.post(SECRETS, json={"value": VALUE})
    client.post(SECRETS, json={"value": VALUE + "2"})
    response = client.delete(SECRETS)
    assert response.status_code == 200
    assert response.json() == {"deleted": 2}
    assert response.headers["cache-control"] == "no-store"
    assert client.get(SECRETS).json() == {"secrets": []}
    assert json.loads(secrets_file.read_text()) == {"secrets": []}


def test_delete_all_with_no_secrets(client):
    assert client.delete(SECRETS).json() == {"deleted": 0}

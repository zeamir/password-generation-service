"""HTTP layer: one router per domain, plus the shared error contract."""

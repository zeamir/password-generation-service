"""Admin endpoints: sample data for demos and tests."""

from fastapi import APIRouter

from vault.config import Settings
from vault.logic.presets import SAMPLE_PRESETS, PresetStore


def admin_router(presets: PresetStore, settings: Settings) -> APIRouter:
    """Builds the router for ``/api/v1/admin``.

    Args:
        presets: The preset store.
        settings: Server settings, which hold the policy ceiling.

    Returns:
        The router.
    """
    router = APIRouter()

    @router.post("/api/v1/admin/sample-presets")
    def add_sample_presets():
        """Adds the sample presets that do not exist yet, leaving existing ones alone."""
        return {"added": presets.add_missing(SAMPLE_PRESETS, settings.max_length_ceiling)}

    return router

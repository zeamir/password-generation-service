"""The error contract: every error is ``{"error": {"code", "message"}}``."""

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from vault.logic.policy import PolicyError
from vault.logic.presets import PresetExistsError, PresetNotFoundError
from vault.logic.secrets import SecretNotFoundError


def error_response(status: int, code: str, message: str) -> JSONResponse:
    """Builds a response in the service's error format.

    Args:
        status: HTTP status code.
        code: Machine-readable error code, e.g. ``invalid_request``.
        message: Human-readable explanation. Must never contain the submitted input.

    Returns:
        A JSON response shaped ``{"error": {"code": ..., "message": ...}}``.
    """
    return JSONResponse(status_code=status, content={"error": {"code": code, "message": message}})


def register_error_handlers(app: FastAPI) -> None:
    """Maps the service's exceptions to error responses.

    Args:
        app: The application to add the handlers to.
    """

    @app.exception_handler(PolicyError)
    async def policy_error_handler(_: Request, exc: PolicyError):
        """Reports an invalid policy or out-of-range length as 400."""
        return error_response(400, "invalid_request", str(exc))

    @app.exception_handler(PresetNotFoundError)
    async def preset_not_found_handler(_: Request, exc: PresetNotFoundError):
        """Reports an unknown preset name as 404."""
        return error_response(404, "not_found", str(exc))

    @app.exception_handler(PresetExistsError)
    async def preset_exists_handler(_: Request, exc: PresetExistsError):
        """Reports a duplicate preset name as 409."""
        return error_response(409, "conflict", str(exc))

    @app.exception_handler(SecretNotFoundError)
    async def secret_not_found_handler(_: Request, exc: SecretNotFoundError):
        """Reports an unknown secret id as 404."""
        return error_response(404, "not_found", str(exc))

    @app.exception_handler(RequestValidationError)
    async def schema_error_handler(_: Request, exc: RequestValidationError):
        """Reports a malformed request body as 422."""
        # Never echo the submitted input back: it may contain a password.
        details = "; ".join(
            f"{'.'.join(str(p) for p in e['loc'] if p != 'body')}: {e['msg']}" for e in exc.errors()
        )
        return error_response(422, "schema_error", details)

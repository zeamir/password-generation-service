"""Endpoints that generate and validate passwords."""

from fastapi import APIRouter
from pydantic import BaseModel, ConfigDict, Field, StrictInt

from vault.logic.passwords import PasswordService
from vault.logic.policy import PolicyOverride
from vault.logic.presets import PresetName

MAX_PASSWORD_INPUT = 1024


class GenerateRequest(BaseModel):
    """Body of ``POST /api/v1/passwords/generate``.

    Attributes:
        length: Desired password length, or None for the policy's ``min_length``.
        preset: Name of the preset to start from, or None to start from the server default.
        policy: Per-request policy override, applied on top of the preset or default.
    """

    model_config = ConfigDict(extra="forbid")

    length: StrictInt | None = None
    preset: PresetName | None = None
    policy: PolicyOverride | None = None


class ValidateRequest(BaseModel):
    """Body of ``POST /api/v1/passwords/validate``.

    Attributes:
        password: The password to check, at most ``MAX_PASSWORD_INPUT`` characters.
        preset: Name of the preset to start from, or None to start from the server default.
        policy: Per-request policy override, applied on top of the preset or default.
    """

    model_config = ConfigDict(extra="forbid")

    password: str = Field(max_length=MAX_PASSWORD_INPUT)
    preset: PresetName | None = None
    policy: PolicyOverride | None = None


def passwords_router(passwords: PasswordService) -> APIRouter:
    """Builds the router for ``/api/v1/passwords``.

    Args:
        passwords: The service that generates and validates passwords.

    Returns:
        The router.
    """
    router = APIRouter()

    @router.post("/api/v1/passwords/generate")
    def generate(body: GenerateRequest):
        """Generates a password that satisfies the effective policy."""
        return {"password": passwords.generate(body.preset, body.policy, body.length)}

    @router.post("/api/v1/passwords/validate")
    def validate(body: ValidateRequest):
        """Checks whether a password satisfies the effective policy."""
        return {"valid": passwords.validate(body.password, body.preset, body.policy)}

    return router

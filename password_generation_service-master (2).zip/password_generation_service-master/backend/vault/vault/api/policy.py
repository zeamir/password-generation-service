"""Endpoint for the server's default policy."""

from fastapi import APIRouter

from vault.config import Settings
from vault.logic.policy import ALPHABET, SPECIAL


def policy_router(settings: Settings) -> APIRouter:
    """Builds the router for ``/api/v1/policy``.

    Args:
        settings: Server settings, which hold the default policy and its ceiling.

    Returns:
        The router.
    """
    router = APIRouter()

    @router.get("/api/v1/policy")
    def get_policy():
        """Returns the server's default policy, its limit, and the allowed characters."""
        return {
            "policy": settings.default_policy.model_dump(),
            "max_length_ceiling": settings.max_length_ceiling,
            "special_characters": SPECIAL,
            "alphabet": ALPHABET,
        }

    return router

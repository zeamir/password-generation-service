"""Endpoints for managing policy presets."""

from fastapi import APIRouter
from fastapi.responses import Response
from pydantic import BaseModel, ConfigDict

from vault.config import Settings
from vault.logic.policy import PolicyOverride
from vault.logic.presets import PresetName, PresetStore


class PresetRequest(BaseModel):
    """Body of ``POST /api/v1/presets``.

    Attributes:
        name: Unique name for the new preset.
        policy: Rules that differ from the server default, or None to copy the default.
    """

    model_config = ConfigDict(extra="forbid")

    name: PresetName
    policy: PolicyOverride | None = None


def presets_router(presets: PresetStore, settings: Settings) -> APIRouter:
    """Builds the router for ``/api/v1/presets``.

    Args:
        presets: The preset store.
        settings: Server settings, which hold the default policy and its ceiling.

    Returns:
        The router.
    """
    router = APIRouter()

    @router.get("/api/v1/presets")
    def list_presets():
        """Lists all presets with their policies."""
        return {
            "presets": [
                {"name": name, "policy": policy.model_dump()}
                for name, policy in presets.list().items()
            ]
        }

    @router.post("/api/v1/presets", status_code=201)
    def add_preset(body: PresetRequest):
        """Adds a preset, after the same consistency checks as any policy."""
        policy = presets.add(
            body.name, body.policy, settings.default_policy, settings.max_length_ceiling
        )
        return {"name": body.name, "policy": policy.model_dump()}

    @router.delete("/api/v1/presets/{name}", status_code=204)
    def remove_preset(name: str):
        """Removes a preset, built-in or user-added."""
        presets.remove(name)
        return Response(status_code=204)

    return router

"""Endpoints for stored secrets."""

import uuid

from fastapi import APIRouter
from fastapi.responses import Response
from pydantic import BaseModel, ConfigDict

from vault.logic.secrets import SecretStore, SecretValue


class SecretRequest(BaseModel):
    """Body of ``POST /api/v1/secrets`` and ``PUT /api/v1/secrets/{id}``.

    Attributes:
        value: The secret value, 1 to 1024 characters.
    """

    model_config = ConfigDict(extra="forbid")

    value: SecretValue


def secrets_router(secrets: SecretStore) -> APIRouter:
    """Builds the router for ``/api/v1/secrets``.

    Args:
        secrets: The secret store.

    Returns:
        The router.
    """
    router = APIRouter()

    @router.get("/api/v1/secrets")
    def list_secrets():
        """Lists all stored secrets, values included."""
        return {"secrets": [s.model_dump(mode="json") for s in secrets.list()]}

    @router.get("/api/v1/secrets/{secret_id}")
    def get_secret(secret_id: uuid.UUID):
        """Returns one stored secret."""
        return secrets.get(secret_id).model_dump(mode="json")

    @router.post("/api/v1/secrets", status_code=201)
    def create_secret(body: SecretRequest):
        """Stores a new secret under a fresh id."""
        return secrets.create(body.value).model_dump(mode="json")

    @router.put("/api/v1/secrets/{secret_id}")
    def update_secret(secret_id: uuid.UUID, body: SecretRequest):
        """Changes a secret's value, keeping its id and creation time."""
        return secrets.update(secret_id, body.value).model_dump(mode="json")

    @router.delete("/api/v1/secrets")
    def delete_all_secrets():
        """Deletes every stored secret."""
        return {"deleted": secrets.clear()}

    @router.delete("/api/v1/secrets/{secret_id}", status_code=204)
    def delete_secret(secret_id: uuid.UUID):
        """Deletes a stored secret."""
        secrets.delete(secret_id)
        return Response(status_code=204)

    return router

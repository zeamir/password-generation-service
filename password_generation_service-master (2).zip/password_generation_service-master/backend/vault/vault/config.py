"""Server configuration, loaded from environment variables at startup."""

import os
from dataclasses import dataclass, field
from pathlib import Path

from vault.logic.policy import Policy

# Default home of the presets and secrets files, relative to where the server starts.
LOCAL_STORAGE_DIR = Path("local_storage")


@dataclass(frozen=True)
class Settings:
    """Immutable server settings.

    Attributes:
        default_policy: Policy applied when a request omits some or all rules.
        max_length_ceiling: Largest ``max_length`` any policy may have.
        cors_origins: Browser origins allowed to call the API.
        presets_file: File that policy presets are saved to, or None to keep them in memory.
        secrets_file: File that stored secrets are saved to, or None to keep them in memory.
    """

    default_policy: Policy = field(default_factory=Policy)
    max_length_ceiling: int = 128
    cors_origins: tuple[str, ...] = ("http://localhost:5173",)
    presets_file: Path | None = None
    secrets_file: Path | None = None

    @classmethod
    def from_env(cls) -> "Settings":
        """Builds settings from the environment, falling back to built-in defaults.

        Reads ``PASSWORD_POLICY_<RULE>`` (one per policy field), ``MAX_LENGTH_CEILING``
        ``CORS_ORIGINS`` (comma-separated), ``PRESETS_FILE`` and ``SECRETS_FILE``. The two
        files default to ``presets.json`` and ``secrets.json`` inside ``LOCAL_STORAGE_DIR``,
        which is created on the first write.

        Returns:
            The settings, with a default policy that has passed ``Policy.check``.

        Raises:
            ValueError: If a numeric variable is not an integer.
            PolicyError: If the resulting default policy is inconsistent, so the
                server refuses to start.
        """
        defaults = Policy()
        policy = Policy(
            **{
                name: int(
                    os.environ.get(f"PASSWORD_POLICY_{name.upper()}", getattr(defaults, name))
                )
                for name in Policy.model_fields
            }
        )
        ceiling = int(os.environ.get("MAX_LENGTH_CEILING", cls.max_length_ceiling))
        origins = os.environ.get("CORS_ORIGINS")
        return cls(
            # Fails fast at startup when the default policy is inconsistent.
            default_policy=policy.check(ceiling),
            max_length_ceiling=ceiling,
            cors_origins=tuple(o.strip() for o in origins.split(","))
            if origins
            else cls.cors_origins,
            presets_file=Path(os.environ.get("PRESETS_FILE", LOCAL_STORAGE_DIR / "presets.json")),
            secrets_file=Path(os.environ.get("SECRETS_FILE", LOCAL_STORAGE_DIR / "secrets.json")),
        )

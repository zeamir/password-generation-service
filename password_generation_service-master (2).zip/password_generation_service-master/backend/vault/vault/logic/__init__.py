"""Business rules: policies, generation and validation, presets and secrets."""

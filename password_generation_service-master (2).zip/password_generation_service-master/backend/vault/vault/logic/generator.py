"""Password generation from a complexity policy, using a cryptographically secure source."""

import secrets

from vault.logic.policy import ALPHABET, DIGITS, LOWERCASE, SPECIAL, UPPERCASE, Policy, PolicyError

_rng = secrets.SystemRandom()


def generate_password(policy: Policy, length: int | None = None) -> str:
    """Generates a random password that satisfies the policy.

    Picks the required minimum from each character class, fills the remaining length
    from the full alphabet, then shuffles. All randomness comes from ``secrets``.

    Args:
        policy: The effective policy the password must satisfy.
        length: Desired length. Defaults to ``policy.min_length``.

    Returns:
        The generated password.

    Raises:
        PolicyError: If ``length`` is outside ``[policy.min_length, policy.max_length]``.
    """
    length = policy.min_length if length is None else length
    if not policy.min_length <= length <= policy.max_length:
        raise PolicyError(
            f"length ({length}) must be between min_length ({policy.min_length}) "
            f"and max_length ({policy.max_length})"
        )

    chars = [secrets.choice(LOWERCASE) for _ in range(policy.min_lowercase)]
    chars += [secrets.choice(UPPERCASE) for _ in range(policy.min_uppercase)]
    chars += [secrets.choice(DIGITS) for _ in range(policy.min_digits)]
    chars += [secrets.choice(SPECIAL) for _ in range(policy.min_special)]
    chars += [secrets.choice(ALPHABET) for _ in range(length - len(chars))]
    _rng.shuffle(chars)
    return "".join(chars)

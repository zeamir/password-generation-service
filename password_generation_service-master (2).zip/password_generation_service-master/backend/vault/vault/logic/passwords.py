"""Password generation and validation against the effective policy of a request."""

from vault.config import Settings
from vault.logic.generator import generate_password
from vault.logic.policy import Policy, PolicyOverride, resolve_policy
from vault.logic.presets import PresetStore
from vault.logic.validator import is_valid_password


class PasswordService:
    """Generates and validates passwords. Nothing it is given is stored or logged."""

    def __init__(self, presets: PresetStore, settings: Settings):
        """Creates the service.

        Args:
            presets: The preset store, for requests that name a preset.
            settings: Server settings, which hold the default policy and its ceiling.
        """
        self._presets = presets
        self._settings = settings

    def effective_policy(self, preset: str | None, override: PolicyOverride | None) -> Policy:
        """Resolves a request's policy: its preset (or the default) plus its override.

        Args:
            preset: Name of the preset to start from, or None for the server default.
            override: Per-request override applied on top.

        Returns:
            The checked policy.

        Raises:
            PresetNotFoundError: If the preset does not exist.
            PolicyError: If the merged policy is not consistent.
        """
        base = self._presets.get(preset) if preset else self._settings.default_policy
        return resolve_policy(base, override, self._settings.max_length_ceiling)

    def generate(
        self, preset: str | None, override: PolicyOverride | None, length: int | None
    ) -> str:
        """Generates a password that satisfies the effective policy.

        Args:
            preset: Name of the preset to start from, or None for the server default.
            override: Per-request override applied on top.
            length: Desired length, or None for the policy's ``min_length``.

        Returns:
            The password.
        """
        return generate_password(self.effective_policy(preset, override), length)

    def validate(self, password: str, preset: str | None, override: PolicyOverride | None) -> bool:
        """Checks whether a password satisfies the effective policy.

        Args:
            password: The password to check.
            preset: Name of the preset to start from, or None for the server default.
            override: Per-request override applied on top.

        Returns:
            True if the password satisfies the policy.
        """
        return is_valid_password(password, self.effective_policy(preset, override))

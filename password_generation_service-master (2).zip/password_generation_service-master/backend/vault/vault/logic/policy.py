"""Password complexity policy: the character sets, the policy models, and merging rules."""

import string
from typing import Self

from pydantic import BaseModel, ConfigDict, StrictInt

LOWERCASE = string.ascii_lowercase
UPPERCASE = string.ascii_uppercase
DIGITS = string.digits
SPECIAL = "!@#$%^&*()-_=+[]{};:,.<>?/~`"
ALPHABET = LOWERCASE + UPPERCASE + DIGITS + SPECIAL


class PolicyError(ValueError):
    """The policy (or a request against it) is semantically invalid."""


class Policy(BaseModel):
    """A complete, immutable password complexity policy.

    Attributes:
        min_length: Minimum total length of the password.
        max_length: Maximum total length of the password.
        min_lowercase: Minimum number of characters from ``a-z``.
        min_uppercase: Minimum number of characters from ``A-Z``.
        min_digits: Minimum number of characters from ``0-9``.
        min_special: Minimum number of characters from ``SPECIAL``.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    min_length: StrictInt = 12
    max_length: StrictInt = 64
    min_lowercase: StrictInt = 1
    min_uppercase: StrictInt = 1
    min_digits: StrictInt = 1
    min_special: StrictInt = 1

    @property
    def required_chars(self) -> int:
        """Total number of characters demanded by the per-class minimums."""
        return self.min_lowercase + self.min_uppercase + self.min_digits + self.min_special

    def check(self, max_length_ceiling: int) -> Self:
        """Verifies that the policy is internally consistent and within server limits.

        Args:
            max_length_ceiling: Largest ``max_length`` the server allows.

        Returns:
            This policy, so the call can be chained.

        Raises:
            PolicyError: If a value is negative, the per-class minimums exceed
                ``min_length``, ``min_length`` exceeds ``max_length``, or ``max_length``
                exceeds ``max_length_ceiling``. The message states which rule failed.
        """
        for name, value in self.model_dump().items():
            if value < 0:
                raise PolicyError(f"{name} must be >= 0, got {value}")
        if self.required_chars > self.min_length:
            raise PolicyError(
                f"the per-class minimums add up to {self.required_chars}, "
                f"which exceeds min_length ({self.min_length})"
            )
        if self.min_length > self.max_length:
            raise PolicyError(
                f"min_length ({self.min_length}) must not exceed max_length ({self.max_length})"
            )
        if self.max_length > max_length_ceiling:
            raise PolicyError(
                f"max_length ({self.max_length}) exceeds the server limit ({max_length_ceiling})"
            )
        return self


class PolicyOverride(BaseModel):
    """A partial policy supplied by the caller; omitted fields fall back to the default.

    Attributes:
        min_length: Override for ``Policy.min_length``, or None to keep the default.
        max_length: Override for ``Policy.max_length``, or None to keep the default.
        min_lowercase: Override for ``Policy.min_lowercase``, or None to keep the default.
        min_uppercase: Override for ``Policy.min_uppercase``, or None to keep the default.
        min_digits: Override for ``Policy.min_digits``, or None to keep the default.
        min_special: Override for ``Policy.min_special``, or None to keep the default.
    """

    model_config = ConfigDict(extra="forbid")

    min_length: StrictInt | None = None
    max_length: StrictInt | None = None
    min_lowercase: StrictInt | None = None
    min_uppercase: StrictInt | None = None
    min_digits: StrictInt | None = None
    min_special: StrictInt | None = None


def resolve_policy(
    default: Policy, override: PolicyOverride | None, max_length_ceiling: int
) -> Policy:
    """Merges a per-request override onto the default policy and validates the result.

    Args:
        default: The server's default policy.
        override: The caller's partial policy, or None to use the default as is.
        max_length_ceiling: Largest ``max_length`` the server allows.

    Returns:
        The effective, validated policy.

    Raises:
        PolicyError: If the merged policy is inconsistent or exceeds the server limit.
    """
    changes = override.model_dump(exclude_none=True) if override else {}
    return default.model_copy(update=changes).check(max_length_ceiling)

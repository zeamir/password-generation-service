"""Named policy presets: a built-in set, optionally persisted to a local JSON file.

The file holds policies, never passwords.
"""

import threading
from typing import Annotated

from pydantic import BaseModel, ConfigDict, StringConstraints, ValidationError

from vault.dal.json_file import JsonFileRepository
from vault.logic.policy import Policy, PolicyError, PolicyOverride, resolve_policy

PresetName = Annotated[
    str,
    StringConstraints(min_length=1, max_length=50, pattern=r"^[A-Za-z0-9][A-Za-z0-9 ._-]*$"),
]

BUILTIN_PRESETS: dict[str, Policy] = {
    "Wi-Fi": Policy(min_length=16, max_length=63, min_special=0),
    "Database": Policy(min_length=24, max_length=64, min_special=0),
    "Banking": Policy(min_length=12, max_length=32),
}


# The presets the admin "sample data" action makes sure exist: the built-ins plus two more
# domains. The accounts service's sample accounts use these names (copied, not shared).
SAMPLE_PRESETS: dict[str, Policy] = {
    **BUILTIN_PRESETS,
    "Workstation": Policy(min_length=14, max_length=64),
    "Cloud": Policy(
        min_length=20,
        max_length=64,
        min_lowercase=1,
        min_uppercase=1,
        min_digits=1,
        min_special=1,
    ),
}


class PresetNotFoundError(LookupError):
    """No preset has the requested name."""


class PresetExistsError(ValueError):
    """A preset with that name already exists."""


class _PresetEntry(BaseModel):
    """One preset as stored in the presets file."""

    model_config = ConfigDict(extra="forbid")

    name: PresetName
    policy: Policy


class PresetStore:
    """The set of named presets, saved to the repository after every change."""

    def __init__(self, presets: dict[str, Policy], repo: JsonFileRepository):
        """Creates a store.

        Args:
            presets: The initial presets by name.
            repo: Where to save after each change. A repository without a path keeps
                presets in memory only.
        """
        self._presets = dict(presets)
        self._repo = repo
        # Sync endpoints run in a thread pool, so changes must not interleave.
        self._lock = threading.Lock()

    @classmethod
    def load(cls, repo: JsonFileRepository, max_length_ceiling: int) -> "PresetStore":
        """Loads presets from ``repo``, or starts from the built-in set if there is no file.

        Once the file exists it is the complete list: a built-in preset that was removed
        stays removed.

        Args:
            repo: The presets file's repository.
            max_length_ceiling: Largest ``max_length`` the server allows.

        Returns:
            The loaded store.

        Raises:
            ValueError: If the file cannot be read or parsed, or names a preset twice.
            PolicyError: If a preset in the file is not a consistent policy, so the
                server refuses to start.
        """
        path = repo.path
        try:
            records = repo.load()
            if records is None:
                return cls(BUILTIN_PRESETS, repo)
            entries = [_PresetEntry.model_validate(record) for record in records]
        except (ValueError, ValidationError) as exc:
            raise ValueError(f"cannot load presets file {path}: {exc}") from exc
        presets: dict[str, Policy] = {}
        for entry in entries:
            if entry.name in presets:
                raise ValueError(f"presets file {path} names {entry.name!r} more than once")
            try:
                presets[entry.name] = entry.policy.check(max_length_ceiling)
            except PolicyError as exc:
                raise PolicyError(f"preset {entry.name!r} in {path}: {exc}") from exc
        return cls(presets, repo)

    def list(self) -> dict[str, Policy]:
        """Returns a snapshot of all presets by name."""
        with self._lock:
            return dict(self._presets)

    def get(self, name: str) -> Policy:
        """Looks up a preset.

        Args:
            name: The preset name.

        Returns:
            The preset's policy.

        Raises:
            PresetNotFoundError: If there is no preset with that name.
        """
        with self._lock:
            if name not in self._presets:
                raise PresetNotFoundError(f"preset {name!r} not found")
            return self._presets[name]

    def add(
        self, name: str, override: PolicyOverride | None, default: Policy, max_length_ceiling: int
    ) -> Policy:
        """Adds a preset and saves the file.

        Args:
            name: The new preset's name.
            override: Rules that differ from ``default``, or None to copy it.
            default: The policy the override is applied to.
            max_length_ceiling: Largest ``max_length`` the server allows.

        Returns:
            The policy that was stored.

        Raises:
            PolicyError: If the resulting policy is not consistent.
            PresetExistsError: If the name is taken.
            OSError: If the file cannot be written. The preset is then not added.
        """
        policy = resolve_policy(default, override, max_length_ceiling)
        with self._lock:
            if name in self._presets:
                raise PresetExistsError(f"preset {name!r} already exists")
            self._commit({**self._presets, name: policy})
        return policy

    def add_missing(self, presets: dict[str, Policy], max_length_ceiling: int) -> tuple[str, ...]:
        """Adds the presets whose names are not taken, saving the file once.

        Args:
            presets: Candidate presets by name. Ones that already exist are left as they are.
            max_length_ceiling: Largest ``max_length`` the server allows.

        Returns:
            The names that were added, empty if none (then nothing is written).

        Raises:
            PolicyError: If an added policy is not consistent. Nothing is then added.
            OSError: If the file cannot be written. Nothing is then added.
        """
        with self._lock:
            new = {
                n: p.check(max_length_ceiling) for n, p in presets.items() if n not in self._presets
            }
            if new:
                self._commit({**self._presets, **new})
            return tuple(new)

    def remove(self, name: str) -> None:
        """Removes a preset, built-in or not, and saves the file.

        Args:
            name: The preset to remove.

        Raises:
            PresetNotFoundError: If there is no preset with that name.
            OSError: If the file cannot be written. The preset is then not removed.
        """
        with self._lock:
            if name not in self._presets:
                raise PresetNotFoundError(f"preset {name!r} not found")
            self._commit({k: v for k, v in self._presets.items() if k != name})

    def _commit(self, presets: dict[str, Policy]) -> None:
        """Saves ``presets`` and only then makes them current, so a failed write changes nothing.

        Args:
            presets: The full new set. The caller must hold the lock.
        """
        self._repo.save([{"name": n, "policy": p.model_dump()} for n, p in presets.items()])
        self._presets = presets

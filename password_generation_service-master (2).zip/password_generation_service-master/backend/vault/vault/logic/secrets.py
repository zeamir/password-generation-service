"""Stored secrets: kept in a local JSON file so they can be listed, changed and removed.

This is a deliberate exception to the service's statelessness: the file holds secret values
unencrypted. Values are never logged, and never appear in error messages.
"""

import threading
import uuid
from datetime import UTC, datetime
from typing import Annotated

from pydantic import BaseModel, ConfigDict, StringConstraints, ValidationError

from vault.dal.json_file import JsonFileRepository

SecretValue = Annotated[str, StringConstraints(min_length=1, max_length=1024)]


class SecretNotFoundError(LookupError):
    """No secret has the requested id."""


class Secret(BaseModel):
    """One stored secret.

    Attributes:
        id: Random UUID v4 assigned by the service.
        value: The secret itself.
        created_at: When the secret was created (UTC).
        updated_at: When the value last changed (UTC).
    """

    model_config = ConfigDict(extra="forbid")

    id: uuid.UUID
    value: SecretValue
    created_at: datetime
    updated_at: datetime


class SecretStore:
    """The set of stored secrets, saved to the repository after every change."""

    def __init__(self, secrets: dict[uuid.UUID, Secret], repo: JsonFileRepository):
        """Creates a store.

        Args:
            secrets: The initial secrets by id.
            repo: Where to save after each change. A repository without a path keeps
                secrets in memory only.
        """
        self._secrets = dict(secrets)
        self._repo = repo
        # Sync endpoints run in a thread pool, so changes must not interleave.
        self._lock = threading.Lock()

    @classmethod
    def load(cls, repo: JsonFileRepository) -> "SecretStore":
        """Loads secrets from ``repo``, or starts empty if there is no file.

        Args:
            repo: The secrets file's repository.

        Returns:
            The loaded store.

        Raises:
            ValueError: If the file cannot be read or parsed, or repeats an id, so the
                server refuses to start. The message never includes secret values.
        """
        path = repo.path
        try:
            records = repo.load()
        except ValueError as exc:
            raise ValueError(f"invalid secrets file: {exc}") from None
        if records is None:
            return cls({}, repo)
        try:
            loaded = [Secret.model_validate(record) for record in records]
        except ValidationError as exc:
            # Pydantic's own message quotes the offending input, which here is a secret.
            problems = "; ".join(
                f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}" for e in exc.errors()
            )
            raise ValueError(f"invalid secrets file {path}: {problems}") from None
        secrets = {secret.id: secret for secret in loaded}
        if len(secrets) != len(loaded):
            raise ValueError(f"secrets file {path} repeats an id")
        return cls(secrets, repo)

    def list(self) -> list[Secret]:
        """Returns a snapshot of all secrets, oldest first."""
        with self._lock:
            return list(self._secrets.values())

    def get(self, secret_id: uuid.UUID) -> Secret:
        """Looks up a secret.

        Args:
            secret_id: The secret's id.

        Returns:
            The secret.

        Raises:
            SecretNotFoundError: If there is no secret with that id.
        """
        with self._lock:
            return self._find(secret_id)

    def create(self, value: str) -> Secret:
        """Stores a new secret and saves the file.

        Args:
            value: The secret value.

        Returns:
            The new secret, with a fresh id and both times set to now.

        Raises:
            OSError: If the file cannot be written. The secret is then not added.
        """
        now = datetime.now(UTC)
        secret = Secret(id=uuid.uuid4(), value=value, created_at=now, updated_at=now)
        with self._lock:
            self._commit({**self._secrets, secret.id: secret})
        return secret

    def update(self, secret_id: uuid.UUID, value: str) -> Secret:
        """Changes a secret's value and saves the file.

        Args:
            secret_id: The secret to change.
            value: The new value.

        Returns:
            The updated secret. Its ``created_at`` is unchanged and ``updated_at`` is now.

        Raises:
            SecretNotFoundError: If there is no secret with that id.
            OSError: If the file cannot be written. The secret is then not changed.
        """
        with self._lock:
            current = self._find(secret_id)
            changed = current.model_copy(update={"value": value, "updated_at": datetime.now(UTC)})
            self._commit({**self._secrets, secret_id: changed})
            return changed

    def delete(self, secret_id: uuid.UUID) -> None:
        """Removes a secret and saves the file.

        Args:
            secret_id: The secret to remove.

        Raises:
            SecretNotFoundError: If there is no secret with that id.
            OSError: If the file cannot be written. The secret is then not removed.
        """
        with self._lock:
            self._find(secret_id)
            self._commit({k: v for k, v in self._secrets.items() if k != secret_id})

    def clear(self) -> int:
        """Removes every secret and saves the file.

        Returns:
            How many secrets were removed.

        Raises:
            OSError: If the file cannot be written. The secrets are then kept.
        """
        with self._lock:
            count = len(self._secrets)
            self._commit({})
            return count

    def _find(self, secret_id: uuid.UUID) -> Secret:
        """Returns the secret with ``secret_id``. The caller must hold the lock."""
        if secret_id not in self._secrets:
            raise SecretNotFoundError(f"secret {secret_id} not found")
        return self._secrets[secret_id]

    def _commit(self, secrets: dict[uuid.UUID, Secret]) -> None:
        """Saves ``secrets`` and only then makes them current, so a failed write changes nothing.

        Args:
            secrets: The full new set. The caller must hold the lock.
        """
        self._repo.save([s.model_dump(mode="json") for s in secrets.values()])
        self._secrets = secrets

"""Password validation against a complexity policy."""

from vault.logic.policy import ALPHABET, DIGITS, LOWERCASE, SPECIAL, UPPERCASE, Policy


def is_valid_password(password: str, policy: Policy) -> bool:
    """Checks whether a password meets the policy.

    Args:
        password: The password to check.
        policy: The effective policy to check against.

    Returns:
        True if the length is within bounds, every character is in the allowed
        alphabet, and each per-class minimum is met; False otherwise.
    """
    if not policy.min_length <= len(password) <= policy.max_length:
        return False
    if any(c not in ALPHABET for c in password):
        return False
    return (
        _count(password, LOWERCASE) >= policy.min_lowercase
        and _count(password, UPPERCASE) >= policy.min_uppercase
        and _count(password, DIGITS) >= policy.min_digits
        and _count(password, SPECIAL) >= policy.min_special
    )


def _count(password: str, charset: str) -> int:
    """Counts the characters of ``password`` that appear in ``charset``."""
    return sum(c in charset for c in password)

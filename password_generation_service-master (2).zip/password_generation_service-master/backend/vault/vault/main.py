"""FastAPI application: wires the stores, routers, error contract and response headers."""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from vault.api.admin import admin_router
from vault.api.errors import register_error_handlers
from vault.api.passwords import passwords_router
from vault.api.policy import policy_router
from vault.api.presets import presets_router
from vault.api.secrets import secrets_router
from vault.config import Settings
from vault.dal.json_file import JsonFileRepository
from vault.logic.passwords import PasswordService
from vault.logic.presets import PresetStore
from vault.logic.secrets import SecretStore


def create_app(settings: Settings | None = None) -> FastAPI:
    """Creates the FastAPI application.

    Args:
        settings: Server settings. Read from the environment if omitted.

    Returns:
        The configured application.
    """
    settings = settings or Settings.from_env()
    # Fails fast at startup when the presets file is unreadable or holds an invalid preset.
    presets = PresetStore.load(
        JsonFileRepository(settings.presets_file, "presets"), settings.max_length_ceiling
    )
    # Likewise for the secrets file.
    secrets = SecretStore.load(JsonFileRepository(settings.secrets_file, "secrets"))
    app = FastAPI(title="Password Generation Service", version="1.0.0")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.cors_origins),
        allow_methods=["GET", "POST", "PUT", "DELETE"],
        allow_headers=["Content-Type"],
    )

    @app.middleware("http")
    async def no_store(request: Request, call_next):
        """Marks every password and secret endpoint response as non-cacheable."""
        response = await call_next(request)
        if request.url.path.startswith(("/api/v1/passwords", "/api/v1/secrets")):
            response.headers["Cache-Control"] = "no-store"
        return response

    register_error_handlers(app)

    @app.get("/health")
    def health():
        """Reports that the service is up."""
        return {"status": "ok"}

    app.include_router(admin_router(presets, settings))
    app.include_router(policy_router(settings))
    app.include_router(presets_router(presets, settings))
    app.include_router(secrets_router(secrets))
    app.include_router(passwords_router(PasswordService(presets, settings)))
    return app


app = create_app()

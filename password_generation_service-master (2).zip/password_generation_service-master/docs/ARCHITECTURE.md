# Architecture

How the Password Generation Service is built. For what it does, see [SPEC.md](../SPEC.md); for how to run it, see the [README](../README.md); for why the big choices were made, see the [decision records](decisions/).

## The pieces

Three apps, run separately:

| App | Path | Owns |
|---|---|---|
| **Vault** (FastAPI, port 8000) | `backend/vault/` | Password policy, presets, stored secrets, generate and validate |
| **Accounts** (FastAPI, port 8001) | `backend/accounts/` | Privileged accounts (details only, never a secret value) |
| **Frontend** (Vite + vanilla JS, port 5173) | `frontend/` | The UI; calls both services directly from the browser |

```mermaid
flowchart LR
    Browser["Frontend (browser)"] -->|"policy, presets, secrets,<br/>generate, validate"| Vault
    Browser -->|accounts| Accounts
    Accounts -->|"GET /api/v1/presets<br/>(VaultClient)"| Vault
    Vault --- P[("presets.json")]
    Vault --- S[("secrets.json")]
    Accounts --- A[("accounts.json")]
```

The two services are separate Poetry projects with separate packages (`vault` and `accounts`) and **never import each other**. The only runtime link is `VaultClient` (in `dal/`), which asks the vault whether a preset exists when an account is created or edited. See [ADR 0001](decisions/0001-two-services-no-shared-code.md).

## Vault service

```
backend/vault/vault/
  main.py        create_app(settings): builds dal -> logic -> api, adds CORS and no-store headers
  config.py      Settings (frozen dataclass), Settings.from_env()
  api/           HTTP only: one router factory per domain, plus errors.py
    policy.py  presets.py  secrets.py  passwords.py  errors.py
  logic/         rules, models and domain errors
    policy.py      Policy, PolicyOverride, resolve_policy, the fixed ALPHABET / SPECIAL
    generator.py   generate_password(policy, length): pure, uses the stdlib `secrets`
    validator.py   is_valid_password(password, policy): pure
    presets.py  secrets.py  passwords.py   PresetStore, SecretStore, PasswordService
  dal/           json_file.py: JsonFileRepository, write_json_atomic (the only file I/O)
```

Services follow [ADR 0007](decisions/0007-api-logic-dal-layers.md): `api` imports `logic`, `logic` imports `dal`, and `dal` imports neither. `main.py` is the only place that builds objects from all three. `tests/test_layers.py` enforces this.

### The policy model

`logic/policy.py` is the core. `Policy` is frozen and complete (min and max length, a minimum count per character class). `PolicyOverride` has every field optional. `resolve_policy` merges an override onto a base (the server default or a preset) and calls `Policy.check`, which raises `PolicyError` for inconsistent rules: negatives, per-class minimums that add up to more than `min_length`, `min_length > max_length`, or `max_length` above the server ceiling. The same check runs on the env-configured default at startup, so a bad default stops the server from starting.

`logic/generator.py` and `logic/validator.py` are pure functions of `(Policy, ...)`. They share one fixed alphabet, so the validator can reject characters the generator would never produce.

### Request flow: generate a password

1. `POST /api/v1/passwords/generate` with `{"length"?, "preset"?, "policy"?}`.
2. Pydantic validates the body (`extra="forbid"`, `StrictInt`). A schema error becomes 422.
3. `PasswordService.effective_policy` takes the named preset if given, else the server default, and calls `resolve_policy` with the request's override. An inconsistent result raises `PolicyError`, which becomes 400.
4. `generate_password` builds a password from the resulting `Policy`. Nothing is stored or logged.
5. The response gets `Cache-Control: no-store` from the middleware in `main.py`.

### Router factories

Each file in `api/` exports a function such as `presets_router(presets, settings)` that takes the services and settings it needs and returns an `APIRouter`. Request models live next to their router. There are no module-level singletons, so tests can build an app with whatever services they like.

### Stores

`PresetStore` and `SecretStore` (in `logic/`) follow one pattern. They keep the rules and the in-memory state, and hand the raw records to a `JsonFileRepository` (in `dal/`) to read and write:

- **In memory, guarded by a lock.** Reads and writes happen under a `threading.Lock`.
- **Save before commit.** Every add, update or remove writes the file first (`JsonFileRepository.save`, via `write_json_atomic`: temp file, then `os.replace`) and only then changes the in-memory state. A failed write leaves both unchanged.
- **Validate at startup.** `load` parses the whole file through pydantic models. A bad file stops the server, the same way a bad default policy does.
- **No optional path means no file.** `Settings(presets_file=None)` keeps everything in memory, which is what tests use unless they pass a `tmp_path`.

### Admin endpoints

`api/admin.py` in each service holds the sample-data actions: the vault's `POST /api/v1/admin/sample-presets` calls `PresetStore.add_missing(SAMPLE_PRESETS, ...)`, and the accounts service's `POST /api/v1/admin/sample-accounts` calls `AccountService.add_samples(count)`. Deleting everything is `DELETE` on the collection (`/api/v1/secrets`, `/api/v1/accounts`), backed by `clear()` on the stores. These use the same save-before-commit rule as every other change.

Presets start from `BUILTIN_PRESETS`. Once the file exists it is the complete list, so a removed built-in stays removed. Secrets are stored unencrypted on purpose ([ADR 0003](decisions/0003-unencrypted-secrets-file.md)) and their values must never appear in logs or error messages, which is why `SecretStore.load` rebuilds pydantic errors without the offending input.

## Accounts service

```
backend/accounts/accounts/
  main.py          create_app(settings, vault): builds dal -> logic -> api
  config.py        Settings, Settings.from_env()
  api/             accounts.py and admin.py (routers), errors.py (the error handlers)
  logic/           accounts.py: AccountFields, Account, AccountStore, AccountService
                   samples.py: SAMPLE_TEMPLATES and sample_accounts() for the Admin tab
  dal/             json_file.py (a deliberate copy of the vault's), vault_client.py
```

An account has a UUID `id`, a unique case-insensitive `name` (editable), a `description` of up to 255 characters, a `preset` name and a `secret_id` that is always null for now (reserved for backlog item PGS-B27).

### Request flow: create an account

1. `POST /api/v1/accounts`, validated like the vault's requests.
2. `AccountService` asks `VaultClient.has_preset(body.preset)`, which calls `GET {VAULT_URL}/api/v1/presets` with a 2-second timeout.
3. Unknown preset: `AccountError`, returned as 400. Vault down, slow or broken: `VaultUnavailableError` (from `dal`), which the service turns into `PresetCheckUnavailableError`, returned as 503 `unavailable`. In both cases nothing is written.
4. Otherwise `AccountStore.create` saves the file, then commits.

Sample accounts take one extra step: `AccountService.add_samples` asks the vault for all preset names once (`VaultClient.preset_names`) and refuses with 400 if a preset the samples use is missing. The names in `SAMPLE_TEMPLATES` are copied from the vault's `SAMPLE_PRESETS`, like the preset-name rule. `AccountStore.add_samples` picks free names and writes under one lock.

Starting the service does not need the vault. Removing a preset in the vault does not touch accounts, so an account can hold a dangling preset name until it is next saved; the frontend shows it as "(missing)".

## Frontend

```
frontend/src/
  api.js       fetch wrapper; account calls go to the accounts service, the rest to the vault
  main.js      page shell, policy form, Generate and Validate panels, tabs
  secrets.js   Secrets view
  accounts.js  Accounts view
  admin.js     Admin view: sample accounts, delete all accounts and secrets
```

- The policy form is pre-filled from `GET /api/v1/policy` and sent with every generate and validate request. The preset dropdown only fills that form; requests never send a preset name.
- `api.js` shows `error.message` from the error contract. The Accounts view shows rejections next to its own form instead of in the top banner.
- Passwords and secrets are never saved in browser storage.

## The error contract

Every error from either service has the same shape: `{"error": {"code": "...", "message": "..."}}`.

| Situation | Status | `code` |
|---|---|---|
| Inconsistent policy (`PolicyError`), or an account naming an unknown preset | 400 | `invalid_request` |
| Unknown preset, secret or account | 404 | `not_found` |
| Duplicate preset or account name | 409 | `conflict` |
| Malformed request body | 422 | `schema_error` |
| Vault unreachable (accounts service only) | 503 | `unavailable` |

The 422 handler lists which fields failed but never echoes the submitted input, because it may be a password ([ADR 0005](decisions/0005-no-input-echo-in-errors.md)).

## Testing approach

- Tests build apps with `create_app(Settings(...))` and explicit paths, never environment variables. Files go in `tmp_path`.
- Vault tests: `test_policy.py` (rules and merge), `test_generator_validator.py` (pure functions), `test_presets.py`, `test_secrets.py`, `test_api.py` (HTTP behavior).
- Accounts tests use a fake vault (`tests/conftest.py`: a tiny FastAPI app serving `GET /api/v1/presets`, wrapped in `TestClient`). Failure cases use an `httpx.MockTransport`.

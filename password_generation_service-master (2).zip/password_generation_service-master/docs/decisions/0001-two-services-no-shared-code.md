# 0001. Two services with no shared code

**Status:** accepted

## Context
The project began as one backend. It then gained privileged accounts, which refer to presets that belong to the password policy. The accounts feature has a different lifecycle (and later, a different owner for its secret references) from generate and validate.

## Decision
Split into a **vault** (policy, presets, secrets, generate, validate) and **accounts** (privileged accounts). They are separate Poetry projects with separate packages and never import each other. The only link is `VaultClient`, which asks the vault whether a preset exists when an account is saved.

## Consequences
- Each service can be run, tested and reasoned about alone. Accounts tests use a fake vault.
- The vault is the single owner of presets. Accounts store a preset *name*, so a preset removed in the vault can leave a dangling name; the UI shows "(missing)" ([ADR 0004](0004-stateless-with-deliberate-exceptions.md) lists what is stored).
- Saving an account needs the vault running (503 otherwise). Starting the service does not.
- A little code is duplicated ([ADR 0002](0002-copied-storage-helper.md)).
- The browser calls two origins, so both services need CORS configured.

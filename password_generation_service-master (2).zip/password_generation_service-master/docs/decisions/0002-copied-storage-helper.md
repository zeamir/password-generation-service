# 0002. Copy the storage helper and preset-name rule

**Status:** accepted

## Context
Both services persist small JSON files with the same atomic-write helper, and the accounts service needs the same preset-name pattern the vault enforces. A shared package would remove the duplication.

## Decision
Copy `write_json_atomic` and the preset-name rule into each service. Do not create a shared library.

## Consequences
- Each service stays a self-contained project; no shared package to version, publish or install ([ADR 0001](0001-two-services-no-shared-code.md)).
- The helper is about 15 lines and rarely changes, so drift risk is low. If a bug is fixed in one copy, fix the other.
- If a third consumer appears, or the shared code grows, revisit this and supersede it with a shared package.

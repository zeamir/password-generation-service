# 0003. Store secrets unencrypted in a local file

**Status:** accepted, for the demo only

## Context
The service can keep secrets that users add (backlog items PGS-B23 onward). Real secret storage needs encryption at rest, key management and access control, which are out of scope for an interview project.

## Decision
`SecretStore` writes values as plain JSON to `Settings.secrets_file`. The README, SPEC and BACKLOG all say so. Compensating measures that do exist:
- values never reach logs or error messages (`SecretStore.load` rebuilds pydantic errors without the input);
- `/api/v1/secrets*` responses carry `Cache-Control: no-store`;
- the accounts file never holds a secret value, only a reference (`secret_id`);
- the file lives in a git-ignored `local_storage/` directory;
- the frontend never persists secrets in browser storage.

## Consequences
- Anyone who can read the file or reach the API can read the secrets. There is no authentication yet (see PGS-B15).
- This is not suitable for real secrets. A production version would use a managed secret store or envelope encryption, and the `SecretStore` interface is small enough to swap.

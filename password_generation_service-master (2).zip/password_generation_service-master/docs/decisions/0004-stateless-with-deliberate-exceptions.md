# 0004. Stateless generate and validate, with two deliberate exceptions

**Status:** accepted

## Context
The core promise is that a password sent to the service is never stored or logged. A service that keeps no state is also easy to scale and reason about.

## Decision
`/api/v1/passwords/*` stays stateless: nothing from a request is stored or logged, and responses carry `Cache-Control: no-store`. Three kinds of data are persisted, each explicitly and each in its own file:
1. **Policy presets** (vault): policies only, never passwords.
2. **Stored secrets** (vault): values the user chose to add ([ADR 0003](0003-unencrypted-secrets-file.md)).
3. **Privileged accounts** (accounts): details only, never a secret value.

## Consequences
- The statelessness claim is precise: it applies to generate and validate, not to the service as a whole. The docs say which data is kept.
- Every new feature that wants to keep data must be listed in the backlog's exceptions and get its own store following the same pattern.

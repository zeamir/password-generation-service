# 0005. Error messages never echo the request input

**Status:** accepted

## Context
FastAPI's default 422 response includes the submitted value for each failing field. For `validate`, that value is a password; for secrets, it is a secret. Echoing it risks leaking it into client logs, proxies and bug reports.

## Decision
Both services replace the default handler. It reports the field path and the validation message only (`password: String should have at most 1024 characters`). `SecretStore.load` does the same for file errors. All errors use one shape: `{"error": {"code", "message"}}`.

## Consequences
- Clients get enough to fix a request, but never see their input reflected back.
- Do not log request bodies and do not put input in error messages when adding new endpoints.
- Debugging a bad request sometimes takes a second step (reproduce it), which is an accepted cost.

# 0006. JSON files instead of a database

**Status:** accepted

## Context
The stored data is small (a handful of presets, secrets and accounts), is read far more than written, and the project must run with only Python and Node installed.

## Decision
Keep each collection in memory behind a lock and save it to a JSON file after every change, using a temp file and `os.replace` so a crash cannot leave a half-written file. Validate the whole file at startup and refuse to start if it is invalid.

## Consequences
- No database to install, configure or migrate; the data is easy to inspect and reset (delete the file).
- One process per file. Two vault instances on the same file would overwrite each other.
- Every write rewrites the whole file, which is fine at this size and not at scale. Swapping in a database later means replacing the store classes; the routers only depend on their methods.

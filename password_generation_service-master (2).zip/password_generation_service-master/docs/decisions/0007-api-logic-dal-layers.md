# 0007. Layer each service as api, logic and dal

**Status:** accepted

## Context
The vault had `api/` and `stores/` with its rules in top-level modules, and the accounts service was flat: routes, models, rules and file I/O in two modules. The stores mixed rules (unique names, built-in presets, not-found errors) with file access, and `VaultClient` imported an error type from the module above it.

## Decision
Both services use the same three packages:

- `api/`: routers, request models and the error handlers. Imports `logic` only.
- `logic/`: rules, domain models and domain errors, the stores and services. Imports `dal` only.
- `dal/`: data access that knows nothing about the domain: `JsonFileRepository` reads and writes raw records, and `VaultClient` (accounts) talks HTTP to the vault. Imports neither of the other layers.

`config.py` is shared by all layers. `main.py` is the composition root: it builds repositories, then logic objects, then routers. `tests/test_layers.py` in each service parses the imports and fails if the rule is broken.

## Consequences
- The rules can be tested without HTTP, and the storage can change without touching routes or rules.
- Errors raised by `dal` are translated in `logic` (for example `VaultUnavailableError` becomes `PresetCheckUnavailableError`), so `api` never sees `dal` types.
- `JsonFileRepository` is copied into each service, as the storage helper was ([ADR 0002](0002-copied-storage-helper.md)).
- Small services get a few more files; for the accounts service the `AccountService` is a thin wrapper over `AccountStore` that adds the vault preset check.

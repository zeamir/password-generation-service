# Decision records

Short notes on the choices in this project that a reader is likely to question. Each one gives the context, the decision and what it costs. Add a new file (next number) when you make a choice like these; do not rewrite an old one, supersede it.

| # | Decision |
|---|---|
| [0001](0001-two-services-no-shared-code.md) | Two services with no shared code |
| [0002](0002-copied-storage-helper.md) | Copy the storage helper and preset-name rule instead of sharing them |
| [0003](0003-unencrypted-secrets-file.md) | Store secrets unencrypted in a local file |
| [0004](0004-stateless-with-deliberate-exceptions.md) | Stateless generate and validate, with two deliberate exceptions |
| [0005](0005-no-input-echo-in-errors.md) | Error messages never echo the request input |
| [0006](0006-json-files-not-a-database.md) | JSON files instead of a database |
| [0007](0007-api-logic-dal-layers.md) | Layer each service as api, logic and dal |

import { createAccount, deleteAccount, listAccounts, listPresets, updateAccount } from "./api.js";

const $ = (id) => document.getElementById(id);

function button(label, onClick) {
  const el = document.createElement("button");
  el.type = "button";
  el.className = "secondary";
  el.textContent = label;
  el.addEventListener("click", onClick);
  return el;
}

/**
 * Wires up the Accounts view: list, create, edit and delete privileged accounts.
 * Errors from the service are shown next to the form.
 * @param {object} helpers Shared helpers from the main page.
 * @param {(action: () => Promise<void>) => Promise<void>} helpers.guarded Runs an action, showing any error at the top of the page.
 * @param {(button: HTMLButtonElement, busyLabel: string, action: () => Promise<void>) => Promise<void>} helpers.withBusy
 *   Runs an action while the button shows a busy label.
 * @returns {() => Promise<void>} Function that reloads accounts and presets from the server.
 */
export function initAccounts({ guarded, withBusy }) {
  const form = $("account-form");
  const formError = $("account-error");
  const list = $("accounts-list");
  const empty = $("accounts-empty");
  const description = $("account-description");
  const presetSelect = $("account-preset");
  const cancel = $("account-cancel");
  let accounts = [];
  let editingId = null;
  let presetNames = new Set();

  function showFormError(message) {
    formError.textContent = message;
    formError.hidden = false;
  }

  // Run a form action, showing a service rejection next to the form instead of at the top.
  async function attempt(action) {
    formError.hidden = true;
    try {
      await action();
    } catch (error) {
      showFormError(error.message);
    }
  }

  function updateCounter() {
    $("description-count").textContent = `${description.value.length}/${description.maxLength}`;
  }

  function resetForm() {
    editingId = null;
    form.reset();
    updateCounter();
    $("account-form-title").textContent = "Add an account";
    $("account-save").textContent = "Add account";
    cancel.hidden = true;
  }

  function startEditing(account) {
    editingId = account.id;
    formError.hidden = true;
    $("account-name").value = account.name;
    description.value = account.description;
    // Keep a preset the vault no longer has selectable, so editing never swaps it silently.
    if (!presetNames.has(account.preset)) presetSelect.append(presetOption(account.preset));
    presetSelect.value = account.preset;
    updateCounter();
    $("account-form-title").textContent = "Edit account";
    $("account-save").textContent = "Save changes";
    cancel.hidden = false;
    $("account-name").focus();
  }

  function presetOption(name) {
    const option = document.createElement("option");
    option.value = name;
    option.textContent = name;
    return option;
  }

  function renderPresetOptions(presets) {
    const selected = presetSelect.value;
    presetNames = new Set(presets.map((p) => p.name));
    presetSelect.replaceChildren(...presets.map(({ name }) => presetOption(name)));
    if (presetNames.has(selected)) presetSelect.value = selected;
  }

  function renderAccount(account) {
    const item = document.createElement("li");
    item.className = "account";

    const name = document.createElement("strong");
    name.textContent = account.name;
    item.append(name);

    if (account.description !== "") {
      const text = document.createElement("p");
      text.className = "account-description";
      text.textContent = account.description;
      item.append(text);
    }

    const details = document.createElement("div");
    details.className = "hint account-details";
    for (const text of [
      `Preset: ${account.preset}${presetNames.has(account.preset) ? "" : " (missing)"}`,
      `Secret: ${account.secret_id === null ? "not set" : "set"}`,
    ]) {
      const part = document.createElement("span");
      part.textContent = text;
      details.append(part);
    }

    const actions = document.createElement("div");
    actions.className = "row";
    actions.append(
      button("Edit", () => startEditing(account)),
      button("Delete", () => {
        if (!confirm(`Delete the account "${account.name}"?`)) return;
        attempt(async () => {
          await deleteAccount(account.id);
          if (editingId === account.id) resetForm();
          await refresh();
        });
      }),
    );
    item.append(details, actions);
    return item;
  }

  async function refresh() {
    const [{ accounts: loaded }, { presets }] = await Promise.all([listAccounts(), listPresets()]);
    accounts = loaded;
    renderPresetOptions(presets);
    empty.hidden = accounts.length > 0;
    list.replaceChildren(...accounts.map(renderAccount));
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    withBusy($("account-save"), "Saving…", () =>
      attempt(async () => {
        const fields = {
          name: $("account-name").value,
          description: description.value,
          preset: presetSelect.value,
        };
        if (editingId === null) await createAccount(fields);
        else await updateAccount(editingId, fields);
        resetForm();
        await refresh();
      }),
    );
  });

  description.addEventListener("input", updateCounter);
  cancel.addEventListener("click", () => {
    formError.hidden = true;
    resetForm();
  });
  updateCounter();

  return () => guarded(refresh);
}

import {
  deleteAllAccounts,
  deleteAllSecrets,
  listAccounts,
  listSecrets,
  loadSampleAccounts,
  loadSamplePresets,
} from "./api.js";

const $ = (id) => document.getElementById(id);

const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;

/**
 * Wires up the Admin view: load sample accounts, and delete all accounts or all secrets.
 * Errors are shown in the banner at the top of the page.
 * @param {object} helpers Shared helpers from the main page.
 * @param {(action: () => Promise<void>) => Promise<void>} helpers.guarded Runs an action, showing any error at the top of the page.
 * @param {(button: HTMLButtonElement, busyLabel: string, action: () => Promise<void>) => Promise<void>} helpers.withBusy
 *   Runs an action while the button shows a busy label.
 * @returns {() => Promise<void>} Function that reloads the account and secret counts.
 */
export function initAdmin({ guarded, withBusy }) {
  const result = $("admin-result");
  const counts = { accounts: 0, secrets: 0 };

  async function refresh() {
    const [{ accounts }, { secrets }] = await Promise.all([listAccounts(), listSecrets()]);
    counts.accounts = accounts.length;
    counts.secrets = secrets.length;
    $("admin-counts").textContent =
      `Currently stored: ${plural(counts.accounts, "account")}, ${plural(counts.secrets, "secret")}.`;
  }

  // Confirm, delete everything of one kind, report how many went, and update the counts.
  function wireDelete(button, kind, remove) {
    button.addEventListener("click", () => {
      if (!confirm(`Delete all ${plural(counts[kind], kind)}? This cannot be undone.`)) return;
      withBusy(button, "Deleting…", async () => {
        const { deleted } = await remove();
        result.textContent = `Deleted ${plural(deleted, kind)}.`;
        await refresh();
      });
    });
  }

  $("samples-form").addEventListener("submit", (event) => {
    event.preventDefault();
    withBusy($("load-samples"), "Loading…", async () => {
      result.textContent = "";
      const { added: presets } = await loadSamplePresets();
      const { added } = await loadSampleAccounts(Number($("sample-count").value));
      result.textContent =
        `Added ${plural(added.length, "account")}.` +
        (presets.length > 0 ? ` Added presets: ${presets.join(", ")}.` : "");
      await refresh();
    });
  });

  wireDelete($("delete-all-accounts"), "account", deleteAllAccounts);
  wireDelete($("delete-all-secrets"), "secret", deleteAllSecrets);

  return () => guarded(refresh);
}

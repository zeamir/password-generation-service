// The backend is two services. Both allow this page's origin through their CORS_ORIGINS.
const VAULT_URL = import.meta.env.VITE_VAULT_URL ?? "http://localhost:8000";
const ACCOUNTS_URL = import.meta.env.VITE_ACCOUNTS_URL ?? "http://localhost:8001";

const vault = { name: "vault", url: VAULT_URL };
const accountsService = { name: "accounts", url: ACCOUNTS_URL };

async function request(service, path, options) {
  let response;
  try {
    response = await fetch(`${service.url}${path}`, options);
  } catch {
    throw new Error(`Cannot reach the ${service.name} service. Is it running?`);
  }
  const body = await response.json().catch(() => null);
  if (!response.ok) {
    throw new Error(body?.error?.message ?? `Request failed (${response.status})`);
  }
  return body;
}

function send(service, method, path, payload) {
  return request(service, path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}

const post = (service, path, payload) => send(service, "POST", path, payload);

/**
 * Fetches the server's default policy and limits.
 * @returns {Promise<{policy: object, max_length_ceiling: number, special_characters: string, alphabet: string}>}
 * @throws {Error} With the server's message, or a connectivity message if unreachable.
 */
export const getPolicy = () => request(vault, "/api/v1/policy");

/**
 * Generates a password that satisfies the given policy.
 * @param {{policy: object, length?: number}} options Policy to send, and optional length.
 * @returns {Promise<{password: string}>}
 * @throws {Error} With the server's message, e.g. for an inconsistent policy.
 */
export const generatePassword = ({ policy, length }) =>
  post(vault, "/api/v1/passwords/generate", length === undefined ? { policy } : { policy, length });

/**
 * Checks whether a password satisfies the given policy.
 * @param {{password: string, policy: object}} options Password to check, and policy to send.
 * @returns {Promise<{valid: boolean}>}
 * @throws {Error} With the server's message, e.g. for an inconsistent policy.
 */
export const validatePassword = ({ password, policy }) =>
  post(vault, "/api/v1/passwords/validate", { password, policy });

/**
 * Lists all policy presets.
 * @returns {Promise<{presets: {name: string, policy: object}[]}>}
 * @throws {Error} With the server's message, or a connectivity message if unreachable.
 */
export const listPresets = () => request(vault, "/api/v1/presets");

/**
 * Saves a new policy preset.
 * @param {{name: string, policy: object}} options Name for the preset, and its policy.
 * @returns {Promise<{name: string, policy: object}>}
 * @throws {Error} With the server's message, e.g. if the name is taken or the policy is inconsistent.
 */
export const savePreset = ({ name, policy }) => post(vault, "/api/v1/presets", { name, policy });

/**
 * Deletes a policy preset, built-in or user-added.
 * @param {string} name Name of the preset to delete.
 * @returns {Promise<null>}
 * @throws {Error} With the server's message, e.g. if there is no such preset.
 */
export const deletePreset = (name) =>
  request(vault, `/api/v1/presets/${encodeURIComponent(name)}`, { method: "DELETE" });

/**
 * Lists all stored secrets, values included.
 * @returns {Promise<{secrets: {id: string, value: string, created_at: string, updated_at: string}[]}>}
 * @throws {Error} With the server's message, or a connectivity message if unreachable.
 */
export const listSecrets = () => request(vault, "/api/v1/secrets");

/**
 * Stores a new secret.
 * @param {string} value The secret value.
 * @returns {Promise<{id: string, value: string, created_at: string, updated_at: string}>}
 * @throws {Error} With the server's message, e.g. if the value is empty.
 */
export const createSecret = (value) => post(vault, "/api/v1/secrets", { value });

/**
 * Changes a stored secret's value.
 * @param {string} id Id of the secret to change.
 * @param {string} value The new value.
 * @returns {Promise<{id: string, value: string, created_at: string, updated_at: string}>}
 * @throws {Error} With the server's message, e.g. if there is no such secret.
 */
export const updateSecret = (id, value) => send(vault, "PUT", `/api/v1/secrets/${id}`, { value });

/**
 * Deletes a stored secret.
 * @param {string} id Id of the secret to delete.
 * @returns {Promise<null>}
 * @throws {Error} With the server's message, e.g. if there is no such secret.
 */
export const deleteSecret = (id) => request(vault, `/api/v1/secrets/${id}`, { method: "DELETE" });

/**
 * Lists all privileged accounts.
 * @returns {Promise<{accounts: object[]}>} Each account has id, name, description, preset
 *   and secret_id (null when no secret is set).
 * @throws {Error} With the server's message, or a connectivity message if unreachable.
 */
export const listAccounts = () => request(accountsService, "/api/v1/accounts");

/**
 * Creates a privileged account.
 * @param {{name: string, description: string, preset: string}} fields
 *   The account's details.
 * @returns {Promise<object>} The new account, with its id.
 * @throws {Error} With the server's message, e.g. if the name is taken, the preset is unknown or the vault is down.
 */
export const createAccount = (fields) => post(accountsService, "/api/v1/accounts", fields);

/**
 * Replaces a privileged account's details.
 * @param {string} id Id of the account to change.
 * @param {{name: string, description: string, preset: string}} fields
 *   The new details.
 * @returns {Promise<object>} The updated account.
 * @throws {Error} With the server's message, e.g. if the new name is taken.
 */
export const updateAccount = (id, fields) =>
  send(accountsService, "PUT", `/api/v1/accounts/${id}`, fields);

/**
 * Deletes a privileged account.
 * @param {string} id Id of the account to delete.
 * @returns {Promise<null>}
 * @throws {Error} With the server's message, e.g. if there is no such account.
 */
export const deleteAccount = (id) =>
  request(accountsService, `/api/v1/accounts/${id}`, { method: "DELETE" });

/**
 * Adds the sample presets the vault lacks (Workstation, Cloud and the built-ins).
 * @returns {Promise<{added: string[]}>} Names of the presets that were added.
 * @throws {Error} With the server's message, or a connectivity message if unreachable.
 */
export const loadSamplePresets = () => post(vault, "/api/v1/admin/sample-presets");

/**
 * Adds sample privileged accounts across several domains.
 * @param {number} count How many accounts to add, 1 to 100.
 * @returns {Promise<{added: object[]}>} The new accounts.
 * @throws {Error} With the server's message, e.g. if the vault lacks a preset or is down.
 */
export const loadSampleAccounts = (count) =>
  post(accountsService, "/api/v1/admin/sample-accounts", { count });

/**
 * Deletes every privileged account.
 * @returns {Promise<{deleted: number}>} How many accounts were removed.
 * @throws {Error} With the server's message, or a connectivity message if unreachable.
 */
export const deleteAllAccounts = () =>
  request(accountsService, "/api/v1/accounts", { method: "DELETE" });

/**
 * Deletes every stored secret.
 * @returns {Promise<{deleted: number}>} How many secrets were removed.
 * @throws {Error} With the server's message, or a connectivity message if unreachable.
 */
export const deleteAllSecrets = () => request(vault, "/api/v1/secrets", { method: "DELETE" });

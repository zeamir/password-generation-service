import {
  deletePreset,
  generatePassword,
  getPolicy,
  listPresets,
  savePreset,
  validatePassword,
} from "./api.js";
import { initAccounts } from "./accounts.js";
import { initAdmin } from "./admin.js";
import { initSecrets } from "./secrets.js";

const LABELS = {
  min_length: "Min length",
  max_length: "Max length",
  min_lowercase: "Min lowercase",
  min_uppercase: "Min uppercase",
  min_digits: "Min digits",
  min_special: "Min special",
};

const $ = (id) => document.getElementById(id);
const policyForm = $("policy-form");
const status = $("status");
const generated = $("generated");
const copyButton = $("copy");
const candidate = $("candidate");
const result = $("result");
const presetSelect = $("preset");
const deletePresetButton = $("delete-preset");
const presetName = $("preset-name");

let defaultPolicy = {};
let presets = [];

function showError(message) {
  status.textContent = message;
  status.hidden = false;
}

function clearError() {
  status.hidden = true;
}

function renderPolicyForm(policy) {
  for (const [name, value] of Object.entries(policy)) {
    const label = document.createElement("label");
    label.textContent = LABELS[name] ?? name;
    const input = document.createElement("input");
    input.type = "number";
    input.name = name;
    input.min = "0";
    input.step = "1";
    input.value = value;
    label.append(input);
    policyForm.append(label);
  }
}

function fillPolicyForm(policy) {
  for (const [name, value] of Object.entries(policy)) {
    policyForm.elements[name].value = value;
  }
}

// Rebuild the preset dropdown; the first option stands for the server default.
function renderPresetOptions(selectedName = "") {
  const options = [
    { name: "", label: "Server default" },
    ...presets.map((p) => ({ ...p, label: p.name })),
  ];
  presetSelect.replaceChildren(
    ...options.map(({ name, label }) => {
      const option = document.createElement("option");
      option.value = name;
      option.textContent = label;
      return option;
    }),
  );
  presetSelect.value = selectedName;
  deletePresetButton.disabled = presetSelect.value === "";
}

async function refreshPresets(selectedName) {
  ({ presets } = await listPresets());
  renderPresetOptions(selectedName);
}

function readPolicy() {
  const policy = {};
  for (const input of policyForm.elements) {
    if (input.name && input.value !== "") policy[input.name] = Number(input.value);
  }
  return policy;
}

// Run an action, showing any error and clearing it on success.
async function guarded(action) {
  clearError();
  try {
    await action();
  } catch (error) {
    showError(error.message);
  }
}

// Disable the button and show a busy label while the action runs, so double submits are ignored.
async function withBusy(button, busyLabel, action) {
  const label = button.textContent;
  button.disabled = true;
  button.setAttribute("aria-busy", "true");
  button.textContent = busyLabel;
  try {
    await guarded(action);
  } finally {
    button.disabled = false;
    button.removeAttribute("aria-busy");
    button.textContent = label;
  }
}

$("generate-form").addEventListener("submit", (event) => {
  event.preventDefault();
  withBusy($("generate-btn"), "Generating…", async () => {
    const lengthValue = $("length").value;
    const { password } = await generatePassword({
      policy: readPolicy(),
      length: lengthValue === "" ? undefined : Number(lengthValue),
    });
    generated.value = password;
    copyButton.disabled = false;
  });
});

copyButton.addEventListener("click", () => {
  guarded(async () => {
    await navigator.clipboard.writeText(generated.value);
    copyButton.textContent = "Copied!";
    copyButton.classList.add("copied");
    setTimeout(() => {
      copyButton.textContent = "Copy";
      copyButton.classList.remove("copied");
    }, 1500);
  });
});

$("validate-form").addEventListener("submit", (event) => {
  event.preventDefault();
  withBusy($("validate-btn"), "Validating…", async () => {
    const { valid } = await validatePassword({ password: candidate.value, policy: readPolicy() });
    result.textContent = valid ? "✅ Valid" : "❌ Not valid";
    result.className = valid ? "ok" : "fail";
  });
});

$("toggle").addEventListener("click", () => {
  const hidden = candidate.type === "password";
  candidate.type = hidden ? "text" : "password";
  $("toggle").textContent = hidden ? "Hide" : "Show";
});

candidate.addEventListener("input", () => {
  result.textContent = "";
  result.className = "";
});

presetSelect.addEventListener("change", () => {
  const preset = presets.find((p) => p.name === presetSelect.value);
  fillPolicyForm(preset ? preset.policy : defaultPolicy);
  deletePresetButton.disabled = !preset;
});

$("save-preset").addEventListener("click", () => {
  guarded(async () => {
    const name = presetName.value.trim();
    if (name === "") throw new Error("Enter a name for the preset.");
    await savePreset({ name, policy: readPolicy() });
    presetName.value = "";
    await refreshPresets(name);
  });
});

deletePresetButton.addEventListener("click", () => {
  const name = presetSelect.value;
  if (!confirm(`Delete the preset "${name}"?`)) return;
  guarded(async () => {
    await deletePreset(name);
    await refreshPresets();
    fillPolicyForm(defaultPolicy);
  });
});

// Reloaded each time its tab opens, so changes made elsewhere (e.g. removed presets) show up.
const refreshers = {
  secrets: initSecrets({ guarded, withBusy, readPolicy }),
  accounts: initAccounts({ guarded, withBusy }),
  admin: initAdmin({ guarded, withBusy }),
  // Sample presets may have been added from the Admin tab since the dropdown was built.
  generator: () => guarded(() => refreshPresets(presetSelect.value)),
};

const tabs = document.querySelectorAll("nav .tab");
for (const tab of tabs) {
  tab.addEventListener("click", () => {
    clearError();
    for (const other of tabs) {
      const active = other === tab;
      $(`page-${other.dataset.page}`).hidden = !active;
      if (active) other.setAttribute("aria-current", "page");
      else other.removeAttribute("aria-current");
    }
    refreshers[tab.dataset.page]?.();
  });
}

guarded(async () => {
  const { policy, special_characters } = await getPolicy();
  defaultPolicy = policy;
  renderPolicyForm(policy);
  $("special-chars").textContent = special_characters;
  await refreshPresets();
});

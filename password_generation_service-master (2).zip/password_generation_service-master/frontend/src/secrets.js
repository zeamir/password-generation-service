import { createSecret, deleteSecret, generatePassword, listSecrets, updateSecret } from "./api.js";

const MASK = "••••••••••••";

const $ = (id) => document.getElementById(id);

function button(label, onClick, className = "secondary") {
  const el = document.createElement("button");
  el.type = "button";
  el.className = className;
  el.textContent = label;
  el.addEventListener("click", onClick);
  return el;
}

function meta(label, iso) {
  const el = document.createElement("span");
  el.textContent = `${label} ${new Date(iso).toLocaleString()}`;
  return el;
}

/**
 * Wires up the Secrets view: list, add, generate, reveal, copy, edit and delete.
 * Values live only in memory and the DOM, never in browser storage.
 * @param {object} helpers Shared helpers from the main page.
 * @param {(action: () => Promise<void>) => Promise<void>} helpers.guarded Runs an action, showing any error.
 * @param {(button: HTMLButtonElement, busyLabel: string, action: () => Promise<void>) => Promise<void>} helpers.withBusy
 *   Runs a guarded action while the button shows a busy label.
 * @param {() => object} helpers.readPolicy Reads the policy from the generator page's form.
 * @returns {() => Promise<void>} Function that reloads the list from the server.
 */
export function initSecrets({ guarded, withBusy, readPolicy }) {
  const list = $("secrets-list");
  const empty = $("secrets-empty");
  const newValue = $("new-secret");
  let secrets = [];
  const revealed = new Set();
  let editingId = null;

  function render() {
    empty.hidden = secrets.length > 0;
    list.replaceChildren(...secrets.map(renderSecret));
  }

  async function refresh() {
    ({ secrets } = await listSecrets());
    render();
  }

  function renderSecret(secret) {
    const item = document.createElement("li");
    item.className = "secret";

    const id = document.createElement("code");
    id.className = "secret-id";
    id.textContent = secret.id;

    const times = document.createElement("div");
    times.className = "hint secret-times";
    times.append(meta("Created", secret.created_at), meta("Updated", secret.updated_at));

    item.append(id, times);
    if (editingId === secret.id) {
      item.append(renderEditor(secret));
    } else {
      item.append(renderValue(secret));
    }
    return item;
  }

  function renderValue(secret) {
    const row = document.createElement("div");
    row.className = "row";
    const value = document.createElement("code");
    value.className = "secret-value";
    const shown = revealed.has(secret.id);
    value.textContent = shown ? secret.value : MASK;
    row.append(
      value,
      button(shown ? "Hide" : "Reveal", () => {
        if (shown) revealed.delete(secret.id);
        else revealed.add(secret.id);
        render();
      }),
      button("Copy", (event) => {
        const copy = event.currentTarget;
        guarded(async () => {
          await navigator.clipboard.writeText(secret.value);
          copy.textContent = "Copied!";
          setTimeout(() => (copy.textContent = "Copy"), 1500);
        });
      }),
      button("Edit", () => {
        editingId = secret.id;
        render();
      }),
      button("Delete", () => {
        if (!confirm("Delete this secret?")) return;
        guarded(async () => {
          await deleteSecret(secret.id);
          revealed.delete(secret.id);
          await refresh();
        });
      }),
    );
    return row;
  }

  function renderEditor(secret) {
    const row = document.createElement("div");
    row.className = "row";
    const input = document.createElement("input");
    input.type = "text";
    input.autocomplete = "off";
    input.setAttribute("aria-label", "New value");
    input.value = secret.value;
    const save = button(
      "Save",
      () =>
        withBusy(save, "Saving…", async () => {
          await updateSecret(secret.id, input.value);
          editingId = null;
          await refresh();
        }),
      "primary",
    );
    row.append(
      input,
      save,
      button("Cancel", () => {
        editingId = null;
        render();
      }),
    );
    return row;
  }

  $("generate-secret").addEventListener("click", (event) => {
    withBusy(event.currentTarget, "Generating…", async () => {
      ({ password: newValue.value } = await generatePassword({ policy: readPolicy() }));
    });
  });

  $("add-secret-form").addEventListener("submit", (event) => {
    event.preventDefault();
    withBusy($("add-secret"), "Adding…", async () => {
      await createSecret(newValue.value);
      newValue.value = "";
      await refresh();
    });
  });

  return () => guarded(refresh);
}
